#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <inttypes.h>
#include <sys/prctl.h>
#include <linux/filter.h>
//#include <seccomp.h>
#include <linux/seccomp.h>
#define DELTA 0x9e3779b9
char *chunk[100];
int *size[100];
void set_secommp();
uint32_t const key[4]= {9,5,2,7};


void xxtea(uint32_t *v, int n, uint32_t const key[4])  
{  
    uint32_t y, z, sum;  
    unsigned i, rounds, e;  
    if (n > 1)            
    {  
        rounds = 6 + 52/n; 
        sum = 0;  
        z = v[n-1];  
        do  
        {  
            sum += DELTA;  
            e = (sum >> 2) & 3;  
            for (i=0; i<n-1; i++) 
            {  
                y = v[i+1];  
                v[i] += (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(i&3)^e] ^ z)));  
                z = v[i];

            }  
            y = v[0];  
            v[n-1] += (((z>>5^y<<2) + (y>>3^z<<4)) ^ ((sum^y) + (key[(i&3)^e] ^ z)));  
            z = v[n-1];
        } 
        while (--rounds);
    }  
}

void set_secommp(){
    prctl(PR_SET_NO_NEW_PRIVS, 1, 0, 0, 0);
    struct sock_filter sfi[] ={
        {0x20,0x00,0x00,0x00000004},
        {0x15,0x00,0x05,0xc000003e},
        {0x20,0x00,0x00,0x00000000},
        {0x35,0x00,0x01,0x40000000},
        {0x15,0x00,0x02,0xffffffff},
        {0x15,0x01,0x00,0x0000003b},
        {0x06,0x00,0x00,0x7fff0000},
        {0x06,0x00,0x00,0x00000000}
    };
    struct sock_fprog sfp = {8, sfi};
    prctl(PR_SET_SECCOMP, SECCOMP_MODE_FILTER, &sfp);
}

void init(){
    setvbuf(stdin,0,2,0);
    setvbuf(stdout,0,2,0);
    setvbuf(stderr,0,2,0);
    memset(chunk, 0, 0x50uLL);
	  set_secommp();
    return ;
}

int read_int(){
    char buf[8];
    read(0,&buf,8);
    return atoi(&buf);
}

int add()
{
  int v2; 
  int v3; 
  printf("Give me a dream ID: ");
  v3 = read_int();
  printf("how long do you want to sleep: ");
  v2 = read_int();
  if (v3 >= 0 && v3 <= 33)
  {
    if(v2>=0&&v2<0x800)
    {
    	if(chunk[v3]==0&&size[v3]==0)
    	{
      	 chunk[v3] = malloc(v2);
     	 size[v3] = v2;
     	 puts("content?");
       int kk = read(0,chunk[v3],size[v3]);
       if(kk==size[v3])
       {
        chunk[v3][kk] = 0;
       }
     	 return puts("Done!\n");
      }
  	}
    else
    {
      puts("Think too much!");
      exit("No!!!");
    }
  }
  else
  {
  	exit("No!!!");
  }
}
int delete()
{
  int v1;
  unsigned int v2;
  puts("Which dream to wake?");
  v1 = read_int();
  if ( v1>=0&&v1<=100)
  {
    if(chunk[v1])
    {
      free(chunk[v1]);
      chunk[v1]=0;
      size[v1]=0;
      v2 = puts("Done!\n");
    }
    else{
    	exit(0);
    }
    
  }
  else
  {
  	exit(0);
  }
  return v2;
}

// int kk()
// {
//   int idx;
//   puts("only one chance");
//   if(hack==1)
//   {
//   	  printf("Which dream to hack?");
// 	  scanf("%d",&idx);
// 	  if(idx>=0&&idx<=4)
// 	  {
// 	  	if(chunk[idx]&&size[idx])
// 	  	{
// 	  		printf("dream: ");
// 	  		read_0(chunk[idx], size[idx]);
// 	  	}
// 	  }
// 	  hack = hack - 1;
//   }
//   else
//   {
//   	exit(0);
//   }
// }
// void show()
// {
//   int idx;
//   printf("Which dream do you want to show?");
//   scanf("%d",&idx);

//   if(idx>=0&&idx<=4)
//   {
//   	if(chunk[idx]&&size[idx])
//   	{
//       int big = size[idx];
//       big = big/4;
//   		xxtea(chunk[idx],big,key);
//   		printf("Content: %s", chunk[idx]);
//   	}
//   }
// }

int menu()
{
  puts("***********************");
  puts("Welcome to the final fantasy");
  puts("1.make a dream");
  puts("2.wake up");
  puts("3.exit");
  puts("***********************");
  return printf("choice: ");
}

int main(int argc, const char **argv, const char **envp)
{
  int v3;
  init();
  while ( 1 )
  {
    while ( 1 )
    {
      menu();
      v3 = read_int();
      if ( v3 != 1 )
        break;
      add();
    }
    if ( v3 == 2 )
    {
      delete();
    }
    else if ( v3 == 3 )
    {
      exit(0);
    }
    else
    {
    	puts("try again?");
    	continue;
    }
  }
}