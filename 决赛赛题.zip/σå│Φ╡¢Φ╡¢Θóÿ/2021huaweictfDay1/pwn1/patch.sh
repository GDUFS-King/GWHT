if [ $# -eq 3 ] ; then
		patchelf --set-interpreter $3 --set-rpath $2 $1
	else
	    echo "usage: ./patch.sh pwnfile libname ld_file"
		exit
fi
