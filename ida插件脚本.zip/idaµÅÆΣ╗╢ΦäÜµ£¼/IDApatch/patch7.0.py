#!/usr/bin/env python
for i in range(182):
	PatchByte(0x600B00+i, Byte(0x600B00+i) ^ 0xc)
	# patch_byte(0x600B00+i, get_wide_byte(0x600B00+i) ^ 0xc)
