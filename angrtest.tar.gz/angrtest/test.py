#!/usr/bin/env python
import angr
import claripy

file = "ree"
flag_length = 32
pie = 0
find_addr = 0x000000000402762
avoid_addr = 0x000000000402710 
hook_addr = 0x0000000004025C0 
hook_canary = 0x00000000040273A 
find_canary = 0x000000000402747
stack_canary = 0x7fffffffdbd8
choice = 3 #[1,2,3]

p = angr.Project(file) #start project
en = p.arch.memory_endness #big or littile 
base_addr = p.loader.main_object.min_addr 
if pie:
	find_addr = base_addr + find_addr
	avoid_addr = base_addr + avoid_addr
	hook_addr = base_addr + hook_addr
	hook_canary = base_addr + hook_canary
	find_canary = base_addr + find_canary

def input_constraints(state,flag_chars):
	# for i in range(flag_length):
	# 	state.solver.add(flag_chars[i]==0x20)
	# 	state.solver.add(flag_chars[i]==0x7E)
	state.solver.add(flag_chars[0]==0x4d)
	state.solver.add(flag_chars[1]==0x77)
	state.solver.add(flag_chars[2]==0x5e)
	state.solver.add(flag_chars[3]==0x0f)

def output_constraints(found,flag_addr):
	enc = [0xBD, 0xAD, 0xB4, 0x84, 0x10, 0x63, 0xB3, 0xE1, 0xC6, 0x84, 0x2D, 0x6F, 0xBA, 0x88, 0x74, 0xC4, 0x90, 0x32, 0xEA, 0x2E, 0xC6, 0x28, 0x65, 0x70, 0xC9, 0x75, 0x78, 0xA0, 0x0B, 0x9F, 0xA6]
	for i in range(len(enc)):
		found.solver.add(found.memory.load(flag_addr+i,1,endness=en)==enc[i])

def get_canary():
	state = p.factory.blank_state(addr=hook_canary)
	state.memory.store(stack_canary,state.solver.BVV(0,8*8),endness=en) #stack_canary
	sm = p.factory.simulation_manager(state) #Parser
	sm.explore(find=find_canary)
	try:
		canary = sm.found[0].solver.eval(sm.found[0].regs.rcx) #get_value from regs
		print("!!!!Canary Find!!!!")
		return canary
	except Exception as e:
		print("!!!!Canary Not Find!!!!")
	
	

def run_angr():
	flag_chars = [claripy.BVS('flag',8*1) for i in range(flag_length)] #flag init
	flag = claripy.Concat(*flag_chars)
	if choice==1: #Stdin input
		state = p.factory.full_init_state(args=[file],add_options=angr.options.unicorn,stdin=flag)
	elif choice==2: #Commandline input
		state = p.factory.entry_state(args=[file,flag])
	else: #Memory input
		canary = get_canary()
		state = p.factory.blank_state(addr=hook_addr)
		state.regs.rax = 0x7fffffffdbaf
		state.regs.rbx = 0
		state.regs.rcx = 0x7fffffffdba0
		state.regs.rdx = 0x3
		state.regs.rdi = 0xc8
		state.regs.rsi = 0x3
		state.regs.r8 = 0xf8ff
		state.regs.r9 = 0x7ffff7fd6700
		state.regs.r10 = 0x309
		state.regs.r11 = 0x7ffff7a987a0
		state.regs.r12 = 0x4006d0
		state.regs.r13 = 0x7fffffffdcd0
		state.regs.r14 = 0
		state.regs.r15 = 0
		state.regs.rbp = 0x7fffffffdbe0
		state.regs.rsp = 0x7fffffffdaa0
		state.memory.store(0x7fffffffdb90,flag)
		state.memory.store(0x7fffffffdbb0,state.solver.BVV(0,8*8),endness=en)
		state.memory.store(0x7fffffffdbb8,state.solver.BVV(0x4027cd,8*8),endness=en)
		state.memory.store(0x7fffffffdbc0,state.solver.BVV(0x7fffffffdbee,8*8),endness=en)
		state.memory.store(0x7fffffffdbc8,state.solver.BVV(0,8*8),endness=en)
		state.memory.store(0x7fffffffdbd0,state.solver.BVV(0x402780,8*8),endness=en)
		state.memory.store(0x7fffffffdbd8,state.solver.BVV(canary,8*8),endness=en) #canary
		state.memory.store(0x7fffffffdbe0,state.solver.BVV(0x7fffffffdbf0,8*8),endness=en) #rbp
		state.memory.store(0x7fffffffdbe8,state.solver.BVV(0x40275E,8*8),endness=en) #ret_addr
		state.memory.store(0x7fffffffdbf0,state.solver.BVV(0x402780,8*8),endness=en)
		state.memory.store(0x7fffffffdbf8,state.solver.BVV(0x7ffff7a2d840,8*8),endness=en) #libc_start_main
	
	input_constraints(state,flag_chars) #Given_condition_input
	sm = p.factory.simulation_manager(state) #Parser
	sm.explore(find=find_addr,avoid=avoid_addr)
	try:
		found = sm.found[0]
		# output_constraints(found,0x6040b0) #Given_condition_output
		get_flag = found.solver.eval(flag,cast_to=bytes)
		print("!!!!Flag Find!!!!")
		print(get_flag)
	except Exception as e:
		print("!!!!Flag Not Find!!!!")

if __name__=="__main__":
	run_angr()